<?php 
	$platrxyz_theme_options = platrxyz_get_theme_options();
	$has_vertical_menu = in_array($platrxyz_theme_options['platr_header_layout'], array('v1','v4')); 
?>
</div><!-- #main .wrapper -->
	<?php if( !is_page_template('page-templates/blank-page-template.php') && $platrxyz_theme_options['platr_footer_block'] ): ?>
	<footer id="colophon" class="footer-container footer-area loading">
		<?php platrxyz_get_footer_content( $platrxyz_theme_options['platr_footer_block'] ); ?>
	</footer>
	<?php endif; ?>
</div><!-- #page -->

<?php if( !is_page_template('page-templates/blank-page-template.php') ): ?>

	<?php if( $has_vertical_menu ): ?>
		<div id="vertical-menu-sidebar" class="vertical-menu-sidebar hidden-phone">
			<div class="overlay"></div>
			<div class="platr-sidebar-content">
				<span class="close"></span>
				<div class="vertical-menu-wrapper">
					<?php
						if( has_nav_menu( 'vertical' ) ){
							wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'vertical-menu', 'theme_location' => 'vertical', 'walker' => new Platrxyz_Walker_Nav_Menu() ) );
						}elseif( has_nav_menu( 'primary' ) ){
							wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'main-menu', 'theme_location' => 'primary', 'walker' => new Platrxyz_Walker_Nav_Menu() ) );
						}
						else{
							wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'main-menu' ) );
						}
					?>
				</div>
			</div>
		</div>
	<?php endif; ?>
		
	<!-- Group Header Button -->
	<div id="group-icon-header" class="platr-floating-sidebar">
		<div class="overlay"></div>
		<div class="platr-sidebar-content <?php echo esc_attr( ( $platrxyz_theme_options['platr_header_layout'] == 'v4' && has_nav_menu( 'vertical' ) ) ? '' : 'no-tab' ); ?>">
		
			<div class="sidebar-content">
				<?php 
					$logo_mobile_menu = is_array($platrxyz_theme_options['platr_logo_menu_mobile'])?$platrxyz_theme_options['platr_logo_menu_mobile']['url']:$platrxyz_theme_options['platr_logo_menu_mobile'];
					$logo_text = $platrxyz_theme_options['platr_text_logo'] ? $platrxyz_theme_options['platr_text_logo'] : get_bloginfo('name');
					
					if( !$logo_mobile_menu ){
						$logo_mobile_menu = is_array($platrxyz_theme_options['platr_logo'])?$platrxyz_theme_options['platr_logo']['url']:$platrxyz_theme_options['platr_logo'];
					}
					if( $logo_mobile_menu ){
				?>
				<div class="logo-wrapper">
					<div class="logo">
						<a href="<?php echo esc_url( home_url('/') ); ?>">
							<img src="<?php echo esc_url($logo_mobile_menu); ?>" loading="lazy" alt="<?php echo esc_attr($logo_text); ?>" class="menu-mobile-logo" />
						</a>
					</div>
				</div>
				<?php } ?>
				
				<ul class="tab-mobile-menu">
					<li id="main-menu" class="active"><span><?php esc_html_e('Menu', 'platrxyz'); ?></span></li>
					<?php if( $has_vertical_menu && has_nav_menu( 'vertical' ) ): ?>
						<li id="vertical-menu"><span><?php esc_html_e('Categories', 'platrxyz'); ?></span></li>
					<?php endif; ?>
				</ul>
				
				<h6 class="menu-title"><span><?php esc_html_e('Menu', 'platrxyz'); ?></span></h6>
				
				<div class="mobile-menu-wrapper platr-menu tab-menu-mobile">
					<div class="menu-main-mobile">
						<?php 
						if( has_nav_menu( 'mobile' ) ){
							wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'mobile-menu', 'theme_location' => 'mobile', 'walker' => new Platrxyz_Walker_Nav_Menu() ) );
						}else{
							if( $has_vertical_menu && has_nav_menu( 'vertical' ) ){
								wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'vertical-menu', 'theme_location' => 'vertical', 'walker' => new Platrxyz_Walker_Nav_Menu() ) );
							}else{
								if( has_nav_menu( 'primary' ) ){
									wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'mobile-menu', 'theme_location' => 'primary', 'walker' => new Platrxyz_Walker_Nav_Menu() ) );
								}else{
									wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'mobile-menu' ) );
								}
							}
						}
						?>
					</div>
				</div>
				
				<?php if( $platrxyz_theme_options['platr_header_layout'] == 'v4' ): ?>
					<div class="mobile-menu-wrapper platr-menu tab-vertical-menu">
						<div class="vertical-menu-wrapper">			
							<?php
								if( has_nav_menu( 'primary' ) ){
									wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'mobile-menu', 'theme_location' => 'primary', 'walker' => new Platrxyz_Walker_Nav_Menu() ) );
								}else{
									wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'mobile-menu' ) );
								}							?>
						</div>
					</div>
				<?php endif; ?>
				
				<div class="group-button-header">
					<?php if( $platrxyz_theme_options['platr_enable_tiny_account'] || $platrxyz_theme_options['platr_header_currency'] || $platrxyz_theme_options['platr_header_language'] ): ?>
					<div class="meta-bottom">
					
						<?php if( $platrxyz_theme_options['platr_header_layout'] != 'v5' && ( $platrxyz_theme_options['platr_header_currency'] || $platrxyz_theme_options['platr_header_language'] ) ): ?>
						<div class="language-currency">
							
							<?php if( $platrxyz_theme_options['platr_header_language'] ): ?>
							<div class="header-language"><?php platrxyz_wpml_language_selector(); ?></div>
							<?php endif; ?>
							
							<?php if( $platrxyz_theme_options['platr_header_currency'] ): ?>
							<div class="header-currency"><?php platrxyz_woocommerce_multilingual_currency_switcher(); ?></div>
							<?php endif; ?>
							
						</div>
						<?php endif; ?>
						
						<?php if( $platrxyz_theme_options['platr_enable_tiny_account'] ): ?>
						<div class="my-account-wrapper">
							<?php echo platrxyz_tiny_account(false); ?>
						</div>	
						<?php endif; ?>
						
					</div>
					<?php endif; ?>
				</div>
				
			</div>	
		</div>
	</div>
		
<?php endif; ?>

<!-- Search Sidebar -->
<?php if( $platrxyz_theme_options['platr_enable_search'] ): ?>
	
	<div id="platr-search-sidebar" class="platr-floating-sidebar">
		<div class="overlay"></div>
		<div class="platr-sidebar-content">
			<div class="platr-search-by-category woocommerce">
				<div class="search--header">
					<h2 class="title"><?php esc_html_e('Search for products', 'platrxyz'); ?> (<span class="count">0</span>)</h2>
					<span class="close"></span>
				</div>
				
				<div class="search--form">
					<?php get_search_form(); ?>
				</div>
				
				<div class="platr-search-result-container"></div>
			</div>
		</div>
	</div>

<?php endif; ?>

<!-- Shopping Cart Floating Sidebar -->
<?php if( class_exists('WooCommerce') && $platrxyz_theme_options['platr_enable_tiny_shopping_cart'] && $platrxyz_theme_options['platr_shopping_cart_sidebar'] && !is_cart() && !is_checkout() ): ?>
<div id="platr-shopping-cart-sidebar" class="platr-floating-sidebar">
	<div class="overlay"></div>
	<div class="platr-sidebar-content">
		<span class="close"></span>
		<div class="platr-tiny-cart-wrapper"></div>
	</div>
</div>
<?php endif; ?>

<?php 
if( ( !wp_is_mobile() && $platrxyz_theme_options['platr_back_to_top_button'] ) || ( wp_is_mobile() && $platrxyz_theme_options['platr_back_to_top_button_on_mobile'] ) ): 
?>
<div id="to-top" class="scroll-button">
	<a class="scroll-button" href="javascript:void(0)" title="<?php esc_attr_e('Back to Top', 'platrxyz'); ?>"><?php esc_html_e('Back to Top', 'platrxyz'); ?></a>
</div>
<?php endif; ?>

<?php 
wp_footer(); ?>
</body>
</html>