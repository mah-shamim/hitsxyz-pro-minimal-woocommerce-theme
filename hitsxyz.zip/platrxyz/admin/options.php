<?php
$redux_url = '';
if( class_exists('ReduxFramework') ){
	$redux_url = ReduxFramework::$_url;
}

$logo_url 					= get_template_directory_uri() . '/images/logo.png'; 
$favicon_url 				= get_template_directory_uri() . '/images/favicon.ico';

$color_image_folder = get_template_directory_uri() . '/admin/assets/images/colors/';
$list_colors = array('default','red');
$preset_colors_options = array();
foreach( $list_colors as $color ){
	$preset_colors_options[$color] = array(
					'alt'      => $color
					,'img'     => $color_image_folder . $color . '.jpg'
					,'presets' => platrxyz_get_preset_color_options( $color )
	);
}

$family_fonts = array(
	"Arial, Helvetica, sans-serif"                          => "Arial, Helvetica, sans-serif"
	,"'Arial Black', Gadget, sans-serif"                    => "'Arial Black', Gadget, sans-serif"
	,"'Bookman Old Style', serif"                           => "'Bookman Old Style', serif"
	,"'Comic Sans MS', cursive"                             => "'Comic Sans MS', cursive"
	,"Courier, monospace"                                   => "Courier, monospace"
	,"Garamond, serif"                                      => "Garamond, serif"
	,"Georgia, serif"                                       => "Georgia, serif"
	,"Impact, Charcoal, sans-serif"                         => "Impact, Charcoal, sans-serif"
	,"'Lucida Console', Monaco, monospace"                  => "'Lucida Console', Monaco, monospace"
	,"'Lucida Sans Unicode', 'Lucida Grande', sans-serif"   => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif"
	,"'MS Sans Serif', Geneva, sans-serif"                  => "'MS Sans Serif', Geneva, sans-serif"
	,"'MS Serif', 'New York', sans-serif"                   => "'MS Serif', 'New York', sans-serif"
	,"'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif"
	,"Tahoma,Geneva, sans-serif"                            => "Tahoma, Geneva, sans-serif"
	,"'Times New Roman', Times,serif"                       => "'Times New Roman', Times, serif"
	,"'Trebuchet MS', Helvetica, sans-serif"                => "'Trebuchet MS', Helvetica, sans-serif"
	,"Verdana, Geneva, sans-serif"                          => "Verdana, Geneva, sans-serif"
	,"CustomFont"                          					=> "CustomFont"
);

$header_layout_options = array();
$header_image_folder = get_template_directory_uri() . '/admin/assets/images/headers/';
for( $i = 1; $i <= 6; $i++ ){
	$header_layout_options['v' . $i] = array(
		'alt'  => sprintf(esc_html__('Header Layout %s', 'platrxyz'), $i)
		,'img' => $header_image_folder . 'header_v'.$i.'.jpg'
	);
}

$loading_screen_options = array();
$loading_image_folder = get_template_directory_uri() . '/images/loading/';
for( $i = 1; $i <= 10; $i++ ){
	$loading_screen_options[$i] = array(
		'alt'  => sprintf(esc_html__('Loading Image %s', 'platrxyz'), $i)
		,'img' => $loading_image_folder . 'loading_'.$i.'.svg'
	);
}

$footer_block_options = platrxyz_get_footer_block_options();

$breadcrumb_layout_options = array();
$breadcrumb_image_folder = get_template_directory_uri() . '/admin/assets/images/breadcrumbs/';
for( $i = 1; $i <= 3; $i++ ){
	$breadcrumb_layout_options['v' . $i] = array(
		'alt'  => sprintf(esc_html__('Breadcrumb Layout %s', 'platrxyz'), $i)
		,'img' => $breadcrumb_image_folder . 'breadcrumb_v'.$i.'.jpg'
	);
}

$sidebar_options = array();
$default_sidebars = platrxyz_get_list_sidebars();
if( is_array($default_sidebars) ){
	foreach( $default_sidebars as $key => $_sidebar ){
		$sidebar_options[$_sidebar['id']] = $_sidebar['name'];
	}
}

$product_loading_image = get_template_directory_uri() . '/images/prod_loading.gif';

$mailchimp_forms = array();
$args = array(
	'post_type'			=> 'mc4wp-form'
	,'post_status'		=> 'publish'
	,'posts_per_page'	=> -1
);
$forms = new WP_Query( $args );
if( !empty( $forms->posts ) && is_array( $forms->posts ) ) {
	foreach( $forms->posts as $p ) {
		$mailchimp_forms[$p->ID] = $p->post_title;
	}
}

$option_fields = array();

/*** General Tab ***/
$option_fields['general'] = array(
	array(
		'id'        => 'section-logo-favicon'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Logo - Favicon', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_logo'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Logo', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Select an image file for the main logo', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => $logo_url )
	)
	,array(
		'id'        => 'platr_logo_mobile'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Mobile Logo', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Display this logo on mobile', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => '' )
	)
	,array(
		'id'        => 'platr_logo_sticky'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Sticky Logo', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Display this logo on sticky header', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => '' )
	)
	,array(
		'id'        => 'platr_logo_menu_mobile'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Mobile Menu Logo', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Display this logo on mobile menu', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => '' )
	)
	,array(
		'id'        => 'platr_logo_width'
		,'type'     => 'text'
		,'url'      => true
		,'title'    => esc_html__( 'Logo Width', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Set width for logo (in pixels)', 'platrxyz' )
		,'default'  => '160'
	)
	,array(
		'id'        => 'platr_device_logo_width'
		,'type'     => 'text'
		,'url'      => true
		,'title'    => esc_html__( 'Logo Width on Device', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Set width for logo (in pixels)', 'platrxyz' )
		,'default'  => '120'
	)
	,array(
		'id'        => 'platr_favicon'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Favicon', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Select a PNG, GIF or ICO image', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => $favicon_url )
	)
	,array(
		'id'        => 'platr_text_logo'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Text Logo', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => 'Platrxyz'
	)

	,array(
		'id'        => 'section-layout-style'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Layout Style', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
	)
	,array(
		'id'        => 'platr_header_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Header Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'required'	=> array( 'platr_layout_fullwidth', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_main_content_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Main Content Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'required'	=> array( 'platr_layout_fullwidth', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_footer_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Footer Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'required'	=> array( 'platr_layout_fullwidth', 'equals', '1' )
	)
	,array(
		'id'       	=> 'platr_layout_style'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Layout Style', 'platrxyz' )
		,'subtitle' => esc_html__( 'You can override this option for the individual page', 'platrxyz' )
		,'desc'     => ''
		,'options'  => array(
			'boxed' 	=> 'Boxed'
			,'wide' 	=> 'Wide'
		)
		,'default'  => 'wide'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
		,'required'	=> array( 'platr_layout_fullwidth', 'equals', '0' )
	)
	
	,array(
		'id'        => 'section-rtl'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Right To Left', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_enable_rtl'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Right To Left', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
	)
	
	,array(
		'id'        => 'section-smooth-scroll'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Smooth Scroll', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_smooth_scroll'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Smooth Scroll', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
	)
	
	,array(
		'id'        => 'section-back-to-top-button'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Back To Top Button', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_back_to_top_button'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Back To Top Button', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'platr_back_to_top_button_on_mobile'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Back To Top Button On Mobile', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'section-page-not-found'
		,'type'     => 'section'
		,'title'    => esc_html__( '404 Page', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_404_page_image'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( '404 Image', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Choose image background for 404 text', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => '' )
	)
	,array( 
		'id'       	=> 'platr_404_page' 
		,'type'     => 'select' 
		,'title'    => esc_html__( '404 Page', 'platrxyz' ) 
		,'subtitle' => esc_html__( 'Select the page which displays the 404 page', 'platrxyz' ) 
		,'desc'     => ''
		,'data'     => 'pages'
		,'default'	=> ''
	)
	,array(
		'id'        => 'section-loading-screen'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Loading Screen', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_loading_screen'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Loading Screen', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
	)
	,array(
		'id'        => 'platr_loading_image'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Loading Image', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $loading_screen_options
		,'default'  => '1'
	)
	,array(
		'id'        => 'platr_custom_loading_image'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Custom Loading Image', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => ''
		,'readonly' => false
		,'default'  => array( 'url' => '' )
	)
	,array(
		'id'       	=> 'platr_display_loading_screen_in'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Display Loading Screen In', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'all-pages' 		=> esc_html__( 'All Pages', 'platrxyz' )
			,'homepage-only' 	=> esc_html__( 'Homepage Only', 'platrxyz' )
			,'specific-pages' 	=> esc_html__( 'Specific Pages', 'platrxyz' )
		)
		,'default'  => 'all-pages'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_loading_screen_exclude_pages'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Exclude Pages', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'data'     => 'pages'
		,'multi'    => true
		,'default'	=> ''
		,'required'	=> array( 'platr_display_loading_screen_in', 'equals', 'all-pages' )
	)
	,array(
		'id'       	=> 'platr_loading_screen_specific_pages'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Specific Pages', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'data'     => 'pages'
		,'multi'    => true
		,'default'	=> ''
		,'required'	=> array( 'platr_display_loading_screen_in', 'equals', 'specific-pages' )
	)
);

/*** Color Scheme Tab ***/
$option_fields['color-scheme'] = array(
	array(
		'id'          => 'platr_color_scheme'
		,'type'       => 'image_select'
		,'presets'    => true
		,'full_width' => false
		,'title'      => esc_html__( 'Select Color Scheme of Theme', 'platrxyz' )
		,'subtitle'   => ''
		,'desc'       => ''
		,'options'    => $preset_colors_options
		,'default'    => 'default'
		,'class'      => ''
	)
	,array(
		'id'        => 'section-general-colors'
		,'type'     => 'section'
		,'title'    => esc_html__( 'General Colors', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'      => 'info-primary-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Primary Colors', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_primary_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Primary Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_text_color_in_bg_primary'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Text Color In Background Primary Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-secondary-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Secondary Colors', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_gray_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Gray Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#848484'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_gray_bg_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Gray Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#efefef'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_text_in_gray_bg_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Text In Gray Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-main-content-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Main Content Colors', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_main_content_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Main Content Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_heading_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Heading Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_dropdown_bg_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Dropdown/Sidebar Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_dropdown_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Dropdown/Sidebar Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Border Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ebebeb'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_link_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Link Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_link_color_hover'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Link Color Hover', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#848484'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_icon_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Icon Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_blockquote_icon_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Blockquote Icon Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#959595'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-tags-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Tags Colors', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_tags_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Tags Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#848484'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_tags_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Tags Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_tags_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Tags Border Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ebebeb'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-input-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Input Colors', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_input_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Input Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_input_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Input Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_input_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Input Border Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ebebeb'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'        => 'section-buttons-color'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Buttons Color', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'      => 'info-default-button'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Default Button', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_button_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Border Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_text_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Text Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_background_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Background Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_border_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Border Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-button-thumbnails-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Icon/Buttons On Product Thumbnail Color (quickview, wishlist, compare...)', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_button_thumbnail_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_thumbnail_bg_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_thumbnail_hover_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Text Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_button_thumbnail_hover_bg_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Button Background Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-breadcrumb-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Breadcrumb Colors', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_breadcrumb_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Breadcrumb Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_breadcrumb_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Breadcrumb Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_breadcrumb_link_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Breadcrumb Link Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#848484'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'        => 'section-header-colors'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Header Colors', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'      => 'info-header-top'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Header Top', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_header_top_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Top Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_top_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Top Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_top_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Top Border Color', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available on some header layouts', 'platrxyz' )
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_top_link_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Top Link Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#848484'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_top_icon_count_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Top Cart/Wishlist Count Number Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_top_icon_count_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Top Cart/Wishlist Count Number Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-header-middle'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Header Middle', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_header_middle_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Middle Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_middle_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Middle Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_middle_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Middle Border Color', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available on some header layouts', 'platrxyz' )
		,'default'  => array(
			'color' 	=> '#ebebeb'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_middle_link_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Middle Link Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_icon_count_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Middle Cart/Wishlist Count Number Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_icon_count_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Middle Cart/Wishlist Count Number Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-header-bottom'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Header Bottom', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_header_bottom_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Bottom Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_bottom_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Bottom Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_bottom_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Bottom Border Color', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available on some header layouts', 'platrxyz' )
		,'default'  => array(
			'color' 	=> '#ebebeb'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_header_bottom_link_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Header Bottom Link Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'        => 'section-footer-colors'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Footer Colors', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'       => 'platr_footer_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Footer Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_footer_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Footer Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#848484'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_footer_link_hover_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Footer Link Hover Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_footer_border_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Footer Border Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d6d6d6'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'        => 'section-product-colors'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Product Colors', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'       => 'platr_product_price_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Product Price Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_sale_price_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Product Sale Price Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#959595'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_rating_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Product Rating Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-product-label-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Product Label Colors (Style on Product Thumbnail)', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_product_sale_label_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Sale Label Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_sale_label_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Sale Label Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#000000'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_new_label_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'New Label Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_new_label_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'New Label Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffa632'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_feature_label_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Feature Label Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_feature_label_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Feature Label Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_outstock_label_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'OutStock Label Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#ffffff'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'       => 'platr_product_outstock_label_background_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'OutStock Label Background Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#919191'
			,'alpha'	=> 1
		)
	)
	,array(
		'id'      => 'info-product-label-meta-colors'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Product Label Colors (Style Label After Product Thumbnail)', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       => 'platr_product_meta_label_text_color'
		,'type'     => 'color_rgba'
		,'title'    => esc_html__( 'Label Text Color', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => array(
			'color' 	=> '#d10202'
			,'alpha'	=> 1
		)
	)
);

/*** Typography Tab ***/
$option_fields['typography'] = array(
	array(
		'id'        => 'section-fonts'
		,'type'     => 'section'
		,'title'    => esc_html__( 'GENERAL FONT', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'       			=> 'platr_body_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Body Font', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'color'   			=> false
		,'letter-spacing' 	=> true
		,'preview'			=> array('always_display' => true)
		,'default'  		=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '400'
			,'font-size'   		=> '15px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.375px'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       			=> 'platr_body_font_medium'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Body Font Medium', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'line-height'  	=> false
		,'font-size'  		=> false
		,'letter-spacing' 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => true)
		,'default'  		=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '500'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       			=> 'platr_body_font_bold'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Body Font Bold', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'line-height'  	=> false
		,'font-size'  		=> false
		,'letter-spacing' 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => true)
		,'default'  		=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '700'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       			=> 'platr_button_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Button Font', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'color'   			=> false
		,'line-height' 		=> false
		,'letter-spacing' 	=> true
		,'text-transform' 	=> true
		,'preview'			=> array('always_display' => true)
		,'default'  			=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '700'
			,'font-size'   		=> '14px'
			,'letter-spacing'   => '1.05px'
			,'text-transform'   => 'uppercase'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       		=> 'platr_blockquote_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Blockquote Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '30px'
			,'line-height' 		=> '48px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'      => 'info-product-price-fonts'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'PRODUCT PRICE FONT SIZE', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       		=> 'platr_single_product_price_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Single Product Price Font Size', 'platrxyz' )
		,'subtitle' 	=> esc_html__( 'Font size of price in product detail page', 'platrxyz' )
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'line-height' 		=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '36px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_single_product_sale_price_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Single Product Sale Price Font Size', 'platrxyz' )
		,'subtitle' 	=> esc_html__( 'Font size of discount price in product detail page', 'platrxyz' )
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'line-height' 		=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '20px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'      => 'info-menu-fonts'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'MAIN MENU FONT', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       			=> 'platr_menu_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Main Menu Font', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'color'   			=> false
		,'letter-spacing' 	=> false
		,'preview'			=> array('always_display' => true)
		,'default'  			=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '400'
			,'font-size'   		=> '16px'
			,'line-height'   	=> '24px'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       		=> 'platr_sub_menu_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Main Menu - Sub Menu Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '14px'
			,'line-height' 		=> '24px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'      => 'info-sidebar-menu-fonts'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'SIDEBAR MENU FONT', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       			=> 'platr_sidebar_menu_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Sidebar Menu Font', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'color'   			=> false
		,'line-height' 		=> true
		,'letter-spacing' 	=> false
		,'preview'			=> array('always_display' => true)
		,'default'  			=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '400'
			,'font-size'   		=> '24px'
			,'line-height'   	=> '28px'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       		=> 'platr_sidebar_submenu_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Sidebar Menu - Sub Menu Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '18px'
			,'line-height' 		=> '24px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'      => 'info-mobile-menu-fonts'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'MOBILE MENU FONT', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       			=> 'platr_mobile_menu_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Mobile Menu Font', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'color'   			=> false
		,'line-height' 		=> true
		,'letter-spacing' 	=> false
		,'preview'			=> array('always_display' => true)
		,'default'  			=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '400'
			,'font-size'   		=> '16px'
			,'line-height'   	=> '24px'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'      => 'info-heading-fonts'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'HEADING FONT', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       			=> 'platr_heading_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Heading Font', 'platrxyz' )
		,'subtitle' 		=> ''
		,'google'   		=> true
		,'font-style'   	=> false
		,'text-align'   	=> false
		,'line-height'  	=> false
		,'font-size'  		=> false
		,'letter-spacing' 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => true)
		,'default'  		=> array(
			'font-family'  		=> 'Inter'
			,'font-weight' 		=> '700'
			,'google'	   		=> true
		)
		,'fonts'	=> $family_fonts
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 20)
	)
	,array(
		'id'       			=> 'platr_h1_font'
		,'type'     		=> 'typography'
		,'title'    		=> esc_html__( 'Font Size H1', 'platrxyz' )
		,'subtitle' 		=> ''
		,'class' 			=> 'typography-no-preview'
		,'google'   		=> false
		,'font-family'  	=> false
		,'font-weight'  	=> false
		,'font-style'   	=> false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '48px'
			,'line-height' 		=> '54px'
			,'letter-spacing' 	=> '3.6px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h2_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Font Size H2', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '36px'
			,'line-height' 		=> '40px'
			,'letter-spacing' 	=> '2.5px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h3_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Font Size H3', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '30px'
			,'line-height' 		=> '36px'
			,'letter-spacing' 	=> '2px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h4_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Font Size H4', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '25px'
			,'line-height' 		=> '30px'
			,'letter-spacing' 	=> '1.2px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h5_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Font Size H5', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '20px'
			,'line-height' 		=> '28px'
			,'letter-spacing' 	=> '1px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h6_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Font Size H6', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '18px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.9px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'        => 'section-font-sizes-responsive'
		,'type'     => 'section'
		,'title'    => esc_html__( 'RESPONSIVE FONT SIZE', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'      => 'info-font-size-tablet'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Tablet', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       		=> 'platr_h1_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H1 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '36px'
			,'line-height' 		=> '40px'
			,'letter-spacing' 	=> '2px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h2_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H2 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '30px'
			,'line-height' 		=> '36px'
			,'letter-spacing' 	=> '1.7px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h3_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H3 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '25px'
			,'line-height' 		=> '30px'
			,'letter-spacing' 	=> '1.2px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h4_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H4 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '20px'
			,'line-height' 		=> '28px'
			,'letter-spacing' 	=> '0.9px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h5_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H5 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '18px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.75px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h6_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H6 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '16px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.75px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_sidebar_menu_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Sidebar Menu Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '18px'
			,'line-height' 		=> '26px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_sidebar_submenu_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Sidebar Sub Menu Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '15px'
			,'line-height' 		=> '24px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_single_product_price_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Single Product Price Font Size', 'platrxyz' )
		,'subtitle' 	=> esc_html__( 'Font size of price in product detail page', 'platrxyz' )
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'line-height' 		=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '25px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_single_product_sale_price_ipad_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'Single Product Sale Price Font Size', 'platrxyz' )
		,'subtitle' 	=> esc_html__( 'Font size of discount price in product detail page', 'platrxyz' )
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> false
		,'line-height' 		=> false
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '18px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'      => 'info-font-size-mobile'
		,'type'   => 'info'
		,'notice' => false
		,'title'  => esc_html__( 'Mobile', 'platrxyz' )
		,'desc'   => ''
	)
	,array(
		'id'       		=> 'platr_h1_mobile_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H1 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '30px'
			,'line-height' 		=> '36px'
			,'letter-spacing' 	=> '1.2px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h2_mobile_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H2 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '25px'
			,'line-height' 		=> '30px'
			,'letter-spacing' 	=> '1px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h3_mobile_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H3 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '20px'
			,'line-height' 		=> '28px'
			,'letter-spacing' 	=> '0.9px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h4_mobile_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H4 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '18px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.75px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h5_mobile_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H5 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '16px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.75px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'       		=> 'platr_h6_mobile_font'
		,'type'     	=> 'typography'
		,'title'    	=> esc_html__( 'H6 Font Size', 'platrxyz' )
		,'subtitle' 	=> ''
		,'class' 		=> 'typography-no-preview'
		,'google'   	=> false
		,'font-family'  => false
		,'font-weight'  => false
		,'font-style'   => false
		,'letter-spacing' 	=> true
		,'text-align'  	 	=> false
		,'color'   			=> false
		,'preview'			=> array('always_display' => false)
		,'default'  		=> array(
			'font-family'  		=> ''
			,'font-weight' 		=> ''
			,'font-size'   		=> '15px'
			,'line-height' 		=> '24px'
			,'letter-spacing' 	=> '0.75px'
			,'google'	   		=> false
		)
	)
	,array(
		'id'        => 'section-custom-font'
		,'type'     => 'section'
		,'title'    => esc_html__( 'CUSTOM FONT', 'platrxyz' )
		,'subtitle' => esc_html__( 'If you get the error message \'Sorry, this file type is not permitted for security reasons\', you can add this line define(\'ALLOW_UNFILTERED_UPLOADS\', true); to the wp-config.php file', 'platrxyz' )
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_custom_font_ttf'
		,'type'     => 'custom_field'
		,'url'      => false
		,'preview'  => false
		,'readonly' => true
		,'title'    => esc_html__( 'Custom Font ttf', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Upload the .ttf font file and save changes', 'platrxyz' )
		,'default'  => array( 'url' => '' )
		,'library_filter'		=> array('ttf')
	)
);

/*** Header Tab ***/
$option_fields['header'] = array(
	array(
		'id'        => 'section-header-options'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Header Options', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_header_layout'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Header Layout', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $header_layout_options
		,'default'  => 'v1'
	)
	,array(
		'id'        => 'platr_header_store_notice'
		,'type'     => 'textarea'
		,'title'    => esc_html__( 'Header Notice', 'platrxyz' )
		,'subtitle' => esc_html__( 'Not available in header layout 5', 'platrxyz' )
		,'validate'	=> 'html'
		,'desc'     => ''
		,'default'  => ''
	)
	,array(
		'id'        => 'platr_header_slide_notice'
		,'type'     => 'multi_text'
		,'title'    => esc_html__( 'Header Notices', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available in header layout 5. Show multiple notices as slider', 'platrxyz' )
		,'desc'     => ''
		,'default'  => array('')
	)
	,array(
		'id'        => 'platr_header_slide_notice_timing'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Notice Animation Timing', 'platrxyz' )
		,'subtitle' => esc_html__( 'The Timing is in seconds. Please put the number only in this field. Default is 30', 'platrxyz' )
		,'desc'     => ''
		,'default'  => ''
	)
	,array(
		'id'        => 'platr_enable_sticky_header'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Sticky Header', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_enable_search'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Search', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_enable_tiny_wishlist'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Wishlist', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_header_currency'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Header Currency', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available on some header layouts. If you don\'t install WooCommerce Multilingual plugin, it may display demo html', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_header_language'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Header Language', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available on some header layouts. If you don\'t install WPML plugin, it may display demo html', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_enable_tiny_account'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'My Account', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_enable_tiny_shopping_cart'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Shopping Cart', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_shopping_cart_sidebar'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Shopping Cart Sidebar', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show shopping cart in sidebar instead of dropdown. You need to update cart after changing', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
		,'required'	=> array( 'platr_enable_tiny_shopping_cart', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_show_shopping_cart_after_adding'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Show Shopping Cart After Adding Product To Cart', 'platrxyz' )
		,'subtitle' => esc_html__( 'You need to enable Ajax add to cart in WooCommerce > Settings > Products', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
		,'required'	=> array( 'platr_shopping_cart_sidebar', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_add_to_cart_effect'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Add To Cart Effect', 'platrxyz' )
		,'subtitle' => esc_html__( 'You need to enable Ajax add to cart in WooCommerce > Settings > Products. If "Show Shopping Cart After Adding Product To Cart" is enabled, this option will be disabled', 'platrxyz' )
		,'options'  => array(
			'0'				=> esc_html__( 'None', 'platrxyz' )
			,'fly_to_cart'	=> esc_html__( 'Fly To Cart', 'platrxyz' )
			,'show_popup'	=> esc_html__( 'Show Popup', 'platrxyz' )
		)
		,'default'  => '0'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	
	,array(
		'id'        => 'platr_enable_header_social_icons'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Header Social Icons', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only available in header layout 5. For other layout please contact our support team.', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_facebook_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Facebook URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => '#'
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_x_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'X URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => '#'
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_instagram_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Instagram URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => '#'
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_pinterest_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Pinterest URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => '#'
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_youtube_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Youtube URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => ''
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_linkedin_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'LinkedIn URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => ''
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_custom_social_url'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Custom Social URL', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => ''
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_custom_social_class'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Custom Social Icon', 'platrxyz' )
		,'subtitle' => esc_html__( 'Put the class of icon. Platrxyz support our custom font with prefix tb-icon-brand- + social name. Ex: tb-icon-brand-facebook. Or you can use font awesome 5. Ex: fab fa-facebook-f', 'platrxyz' )
		,'desc'     => ''
		,'default'  => ''
		,'required'	=> array( 'platr_enable_header_social_icons', 'equals', '1' )
	)
	
	,array(
		'id'        => 'section-breadcrumb-options'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Breadcrumb Options', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_breadcrumb_layout'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Breadcrumb Layout', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $breadcrumb_layout_options
		,'default'  => 'v1'
	)
	,array(
		'id'        => 'platr_enable_breadcrumb_background_image'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Breadcrumbs Background Image', 'platrxyz' )
		,'subtitle' => esc_html__( 'You can set background color by going to Color Scheme tab > Breadcrumb Colors section', 'platrxyz' )
		,'default'  => true
	)
	,array(
		'id'        => 'platr_bg_breadcrumbs'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Breadcrumbs Background Image', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => esc_html__( 'Select a new image to override the default background image', 'platrxyz' )
		,'readonly' => false
		,'default'  => array( 'url' => '' )
	)
	,array(
		'id'        => 'platr_breadcrumb_bg_parallax'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Breadcrumbs Background Parallax', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
	)
	,array(
		'id'        => 'platr_breadcrumb_product_taxonomy_description'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Taxonomy Description In Breadcrumbs', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show product taxonomy description (category, tags, ...) in breadcrumbs area on the product taxonomy page', 'platrxyz' )
		,'default'  => false
	)
);

/*** Footer Tab ***/
$option_fields['footer'] = array(
	array(
		'id'       	=> 'platr_footer_block'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Footer Block', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $footer_block_options
		,'default'  => '0'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
);

/*** Menu Tab ***/
$option_fields['menu'] = array(
	array(
		'id'             => 'platr_menu_thumb_width'
		,'type'          => 'slider'
		,'title'         => esc_html__( 'Menu Thumbnail Width', 'platrxyz' )
		,'subtitle'      => ''
		,'desc'          => esc_html__( 'Min: 5, max: 60, step: 1, default value: 54', 'platrxyz' )
		,'default'       => 54
		,'min'           => 5
		,'step'          => 1
		,'max'           => 60
		,'display_value' => 'text'
	)
	,array(
		'id'             => 'platr_menu_thumb_height'
		,'type'          => 'slider'
		,'title'         => esc_html__( 'Menu Thumbnail Height', 'platrxyz' )
		,'subtitle'      => ''
		,'desc'          => esc_html__( 'Min: 5, max: 60, step: 1, default value: 54', 'platrxyz' )
		,'default'       => 54
		,'min'           => 5
		,'step'          => 1
		,'max'           => 60
		,'display_value' => 'text'
	)
	,array(
		'id'        => 'platr_enable_menu_overlay'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Menu Background Overlay', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Enable', 'platrxyz' )
		,'off'		=> esc_html__( 'Disable', 'platrxyz' )
	)
);

/*** Blog Tab ***/
$option_fields['blog'] = array(
	array(
		'id'        => 'section-blog'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Blog', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_blog_layout'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Blog Layout', 'platrxyz' )
		,'subtitle' => esc_html__( 'This option is available when Front page displays the latest posts', 'platrxyz' )
		,'desc'     => ''
		,'options'  => array(
			'0-1-0' => array(
				'alt'  => esc_html__('Fullwidth', 'platrxyz')
				,'img' => $redux_url . 'assets/img/1col.png'
			)
			,'1-1-0' => array(
				'alt'  => esc_html__('Left Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cl.png'
			)
			,'0-1-1' => array(
				'alt'  => esc_html__('Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cr.png'
			)
			,'1-1-1' => array(
				'alt'  => esc_html__('Left & Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/3cm.png'
			)
		)
		,'default'  => '0-1-1'
	)
	,array(
		'id'       	=> 'platr_blog_left_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Left Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'blog-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_blog_right_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Right Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'blog-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_blog_columns'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Blog Columns', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			1	=> 1
			,2	=> 2
			,3	=> 3
		)
		,'default'  => '1'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_blog_item_layout'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Blog Item Layout', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'item-grid'		=> esc_html__( 'Grid', 'platrxyz' )
			,'item-list'	=> esc_html__( 'List', 'platrxyz' )
		)
		,'default'	=> 'item-grid'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_blog_thumbnail'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Thumbnail', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_date'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Date', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_title'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Title', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_author'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Author', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_comment'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Comment', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_read_more'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Read More Button', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_categories'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Categories', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_excerpt'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Excerpt', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_excerpt_strip_tags'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Excerpt Strip All Tags', 'platrxyz' )
		,'subtitle' => esc_html__( 'Strip all html tags in Excerpt', 'platrxyz' )
		,'default'  => false
	)
	,array(
		'id'        => 'platr_blog_excerpt_max_words'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Blog Excerpt Max Words', 'platrxyz' )
		,'subtitle' => esc_html__( 'Input -1 to show full excerpt', 'platrxyz' )
		,'desc'     => ''
		,'default'  => '-1'
	)

	,array(
		'id'        => 'section-blog-details'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Blog Details', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_blog_details_layout'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Blog Details Layout', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'0-1-0' => array(
				'alt'  => esc_html__('Fullwidth', 'platrxyz')
				,'img' => $redux_url . 'assets/img/1col.png'
			)
			,'1-1-0' => array(
				'alt'  => esc_html__('Left Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cl.png'
			)
			,'0-1-1' => array(
				'alt'  => esc_html__('Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cr.png'
			)
			,'1-1-1' => array(
				'alt'  => esc_html__('Left & Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/3cm.png'
			)
		)
		,'default'  => '0-1-0'
	)
	,array(
		'id'       	=> 'platr_blog_details_left_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Left Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'blog-detail-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_blog_details_right_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Right Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'blog-detail-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_blog_details_thumbnail'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Thumbnail', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'       	=> 'platr_blog_details_thumbnail_style'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Blog Thumbnail Style', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'thumbnail-default'		=> esc_html__( 'Default', 'platrxyz' )
			,'thumbnail-parallax'	=> esc_html__( 'Parallax', 'platrxyz' )
		)
		,'default'	=> 'thumbnail-default'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_blog_details_date'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Date', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_title'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Title', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_author'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Author', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_comment'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Comment', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_content'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Content', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_tags'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Tags', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_categories'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Categories', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_sharing'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Sharing', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_sharing_sharethis'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Sharing - Use ShareThis', 'platrxyz' )
		,'subtitle' => esc_html__( 'Use share buttons from sharethis.com. You need to add key below', 'platrxyz')
		,'default'  => true
		,'required'	=> array( 'platr_blog_details_sharing', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_blog_details_sharing_sharethis_key'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Blog Sharing - ShareThis Key', 'platrxyz' )
		,'subtitle' => esc_html__( 'You get it from script code. It is the value of "property" attribute', 'platrxyz' )
		,'desc'     => ''
		,'default'  => ''
		,'required'	=> array( 'platr_blog_details_sharing', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_blog_details_author_box'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Author Box', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_navigation'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Navigation', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_related_posts'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Related Posts', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_blog_details_comment_form'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Blog Comment Form', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
);

/*** WooCommerce Tab ***/
$option_fields['woocommerce'] = array(
	array(
		'id'        => 'section-product-label'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Product Label', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'       	=> 'platr_product_label_style'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Label Style', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'rectangle' 	=> esc_html__( 'Rectangle', 'platrxyz' )
			,'square' 		=> esc_html__( 'Square', 'platrxyz' )
			,'circle' 		=> esc_html__( 'Circle', 'platrxyz' )
		)
		,'default'  => 'rectangle'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_product_label_pos'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Label Position', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'on-thumbnail' 		=> esc_html__( 'On Thumbnail', 'platrxyz' )
			,'after-thumbnail' 	=> esc_html__( 'After Thumbnail', 'platrxyz' )
		)
		,'default'  => 'on-thumbnail'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_product_show_new_label'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product New Label', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_product_new_label_text'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product New Label Text', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => 'New'
		,'required'	=> array( 'platr_product_show_new_label', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_product_show_new_label_time'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product New Label Time', 'platrxyz' )
		,'subtitle' => esc_html__( 'Number of days which you want to show New label since product is published', 'platrxyz' )
		,'desc'     => ''
		,'default'  => '30'
		,'required'	=> array( 'platr_product_show_new_label', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_product_feature_label_text'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Feature Label Text', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => 'Hot'
	)
	,array(
		'id'        => 'platr_product_out_of_stock_label_text'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Out Of Stock Label Text', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => 'Sold out'
	)
	,array(
		'id'       	=> 'platr_show_sale_label_as'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Show Sale Label As', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'text' 		=> esc_html__( 'Text', 'platrxyz' )
			,'number' 	=> esc_html__( 'Number', 'platrxyz' )
			,'percent' 	=> esc_html__( 'Percent', 'platrxyz' )
		)
		,'default'  => 'percent'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_product_sale_label_text'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Sale Label Text', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => 'Sale'
	)
	,array(
		'id'        => 'platr_product_sale_percent_prefix'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Sale Label Prefix', 'platrxyz' )
		,'subtitle' => esc_html__( 'This text will be shown before amount discount in the After Thumbnail style', 'platrxyz' )
		,'desc'     => ''
		,'default'  => 'Sale off'
		,'required'	=> array( array('platr_product_label_pos', 'equals', 'after-thumbnail'), array('platr_show_sale_label_as', '!=', 'text') )
	)
	
	,array(
		'id'        => 'section-product-hover'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Product Hover', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'       	=> 'platr_product_hover_style'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Hover Style', 'platrxyz' )
		,'subtitle' => esc_html__( 'Select the style of buttons/icons when hovering on product', 'platrxyz' )
		,'desc'     => ''
		,'options'  => array(
			'hover-horizontal-style' 			=> esc_html__( 'Horizontal Style', 'platrxyz' )
			,'hover-vertical-style' 		=> esc_html__( 'Vertical Style', 'platrxyz' )
		)
		,'default'  => 'hover-vertical-style'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_effect_product'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Back Product Image', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show another product image on hover. It will show an image from Product Gallery', 'platrxyz' )
		,'default'  => false
	)
	,array(
		'id'        => 'platr_product_tooltip'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Tooltip', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show tooltip when hovering on buttons/icons on product', 'platrxyz' )
		,'default'  => true
	)
	
	,array(
		'id'        => 'section-lazy-load'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Lazy Load', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_prod_lazy_load'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Activate Lazy Load', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
	)
	,array(
		'id'        => 'platr_prod_placeholder_img'
		,'type'     => 'media'
		,'url'      => true
		,'title'    => esc_html__( 'Placeholder Image', 'platrxyz' )
		,'desc'     => ''
		,'subtitle' => ''
		,'readonly' => false
		,'default'  => array( 'url' => $product_loading_image )
	)
	
	,array(
		'id'        => 'section-quickshop'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Quickshop', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_enable_quickshop'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Activate Quickshop', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)

	,array(
		'id'        => 'section-catalog-mode'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Catalog Mode', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_enable_catalog_mode'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Catalog Mode', 'platrxyz' )
		,'subtitle' => esc_html__( 'Hide all Add To Cart buttons on your site. You can also hide Shopping cart by going to Header tab > turn Shopping Cart option off', 'platrxyz' )
		,'default'  => false
	)
	
	,array(
		'id'        => 'section-ajax-search'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Ajax Search', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_ajax_search'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Enable Ajax Search', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'platr_ajax_search_number_result'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Number Of Results', 'platrxyz' )
		,'subtitle' => esc_html__( 'Input -1 to show all results', 'platrxyz' )
		,'desc'     => ''
		,'default'  => '6'
	)
);

/*** Shop/Product Category Tab ***/
$option_fields['shop-product-category'] = array(
	array(
		'id'        => 'platr_prod_cat_layout'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Shop/Product Category Layout', 'platrxyz' )
		,'subtitle' => esc_html__( 'Sidebar is only available if Filter Widget Area is disabled', 'platrxyz' )
		,'desc'     => ''
		,'options'  => array(
			'0-1-0' => array(
				'alt'  => esc_html__('Fullwidth', 'platrxyz')
				,'img' => $redux_url . 'assets/img/1col.png'
			)
			,'1-1-0' => array(
				'alt'  => esc_html__('Left Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cl.png'
			)
			,'0-1-1' => array(
				'alt'  => esc_html__('Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cr.png'
			)
			,'1-1-1' => array(
				'alt'  => esc_html__('Left & Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/3cm.png'
			)
		)
		,'default'  => '0-1-0'
	)
	,array(
		'id'       	=> 'platr_prod_cat_left_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Left Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'product-category-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_prod_cat_right_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Right Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'product-category-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_prod_cat_grid_list_toggle'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Grid/List Toggle', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'       	=> 'platr_prod_grid_list_toggle_default'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Grid/List Toggle Default', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'grid'		=> esc_html__( 'Grid', 'platrxyz' ),
			'list'		=> esc_html__( 'List', 'platrxyz' )
		)
		,'default'  => 'grid'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
		,'required'	=> array('platr_prod_cat_grid_list_toggle', 'equals', '1')
	)
	,array(
		'id'       	=> 'platr_prod_cat_columns'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Columns', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'3'			=> '3'
			,'4'		=> '4'
			,'5'		=> '5'
			,'6'		=> '6'
		)
		,'default'  => '4'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_prod_cat_per_page'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Products Per Page', 'platrxyz' )
		,'subtitle' => esc_html__( 'Number of products per page', 'platrxyz' )
		,'desc'     => ''
		,'default'  => '12'
	)
	,array(
		'id'       	=> 'platr_prod_cat_loading_type'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Loading Type', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'default'			=> esc_html__( 'Default', 'platrxyz' )
			,'infinity-scroll'	=> esc_html__( 'Infinity Scroll', 'platrxyz' )
			,'load-more-button'	=> esc_html__( 'Load More Button', 'platrxyz' )
			,'ajax-pagination'	=> esc_html__( 'Ajax Pagination', 'platrxyz' )
		)
		,'default'  => 'ajax-pagination'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_prod_cat_collapse_scroll_sidebar'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Collapse And Scroll Widgets In Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_cat_per_page_dropdown'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Products Per Page Dropdown', 'platrxyz' )
		,'subtitle' => esc_html__( 'Allow users to select number of products per page', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_onsale_checkbox'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Products On Sale Checkbox', 'platrxyz' )
		,'subtitle' => esc_html__( 'Allow users to view only the discounted products', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_filter_widget_area'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Filter Widget Area', 'platrxyz' )
		,'subtitle' => esc_html__( 'Display Filter Widget Area on the Shop/Product Category page. If enabled, sidebar will be removed', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'		=> 'platr_filter_widget_area_style'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Filter Widget Area Style', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'dropdown'			=> esc_html__( 'Dropdown', 'platrxyz' )
			,'sidebar'			=> esc_html__( 'Sidebar', 'platrxyz' )
			,'floating-sidebar'	=> esc_html__( 'Floating Sidebar', 'platrxyz' )
		)
		,'default'  => 'dropdown'
		,'select2'	=> array( 'allowClear' => false, 'minimumResultsForSearch' => 'Infinity' )
		,'required'	=> array( 'platr_filter_widget_area', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_cat_filter_heading'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Filter Sidebar Heading', 'platrxyz' )
		,'subtitle' => esc_html__( 'Used in Floating Sidebar', 'platrxyz' )
		,'desc'     => ''
		,'default'  => 'Filter Products'
	)
	,array(
		'id'		=> 'platr_show_filter_widget_area_by_default'
		,'type'		=> 'switch'
		,'title'	=> esc_html__( 'Show Filter Widget Area By Default', 'platrxyz' )
		,'subtitle'	=> ''
		,'desc'		=> ''
		,'default'	=> false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
		,'required'	=> array( 'platr_filter_widget_area_style', 'equals', 'sidebar' )	
	)
	,array(
		'id'        => 'platr_prod_cat_thumbnail'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Thumbnail', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_label'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Label', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_brand'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Brands', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_cat'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Categories', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_title'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Title', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_sku'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product SKU', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_rating'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Rating', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_price'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Price', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_add_to_cart'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Add To Cart Button', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_desc'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Short Description - Grid View', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show product description on grid view', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_desc_words'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Short Description - Grid View - Limit Words', 'platrxyz' )
		,'subtitle' => esc_html__( 'Number of words to show product description on grid view. It is also used for product elements', 'platrxyz' )
		,'desc'     => ''
		,'default'  => '10'
	)
	,array(
		'id'        => 'platr_prod_cat_list_desc'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Short Description - List View', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show product description on list view', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat_list_desc_words'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Short Description - List View - Limit Words', 'platrxyz' )
		,'subtitle' => esc_html__( 'Number of words to show product description on list view', 'platrxyz' )
		,'desc'     => ''
		,'default'  => '50'
	)
	,array(
		'id'        => 'platr_prod_cat_color_swatch'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Color Swatches', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show the color attribute of variations. The slug of the color attribute has to be "color"', 'platrxyz' )
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'       	=> 'platr_prod_cat_number_color_swatch'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Number Of Color Swatches', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			2	=> 2
			,3	=> 3
			,4	=> 4
			,5	=> 5
			,6	=> 6
		)
		,'default'  => '3'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
		,'required'	=> array( 'platr_prod_cat_color_swatch', 'equals', '1' )
	)
);

/*** Product Details Tab ***/
$option_fields['product-details'] = array(
	array(
		'id'        => 'platr_prod_layout'
		,'type'     => 'image_select'
		,'title'    => esc_html__( 'Product Layout', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'0-1-0' => array(
				'alt'  => esc_html__('Fullwidth', 'platrxyz')
				,'img' => $redux_url . 'assets/img/1col.png'
			)
			,'1-1-0' => array(
				'alt'  => esc_html__('Left Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cl.png'
			)
			,'0-1-1' => array(
				'alt'  => esc_html__('Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/2cr.png'
			)
			,'1-1-1' => array(
				'alt'  => esc_html__('Left & Right Sidebar', 'platrxyz')
				,'img' => $redux_url . 'assets/img/3cm.png'
			)
		)
		,'default'  => '0-1-0'
	)
	,array(
		'id'       	=> 'platr_prod_left_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Left Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'product-detail-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_prod_right_sidebar'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Right Sidebar', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => $sidebar_options
		,'default'  => 'product-detail-sidebar'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_prod_layout_fullwidth'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Layout Fullwidth', 'platrxyz' )
		,'subtitle' => esc_html__( 'Override the Layout Fullwidth option in the General tab', 'platrxyz' )
		,'desc'     => ''
		,'options'  => array(
			'default'	=> esc_html__( 'Default', 'platrxyz' )
			,'0'		=> esc_html__( 'No', 'platrxyz' )
			,'1'		=> esc_html__( 'Yes', 'platrxyz' )
		)
		,'default'  => 'default'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_prod_header_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Header Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'required'	=> array( 'platr_prod_layout_fullwidth', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_main_content_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Main Content Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'required'	=> array( 'platr_prod_layout_fullwidth', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_footer_layout_fullwidth'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Footer Layout Fullwidth', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'required'	=> array( 'platr_prod_layout_fullwidth', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_breadcrumb'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Breadcrumb', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_cloudzoom'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Cloud Zoom', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_lightbox'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Lightbox', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_attr_dropdown'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Attribute Dropdown', 'platrxyz' )
		,'subtitle' => esc_html__( 'If you turn it off, the dropdown will be replaced by image or text label', 'platrxyz' )
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_attr_color_text'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Color Attribute Text', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show text for the Color attribute instead of color/color image', 'platrxyz' )
		,'default'  => false
		,'required'	=> array( 'platr_prod_attr_dropdown', 'equals', '0' )
	)
	,array(
		'id'        => 'platr_prod_attr_color_variation_thumbnail'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Color Attribute Variation Thumbnail', 'platrxyz' )
		,'subtitle' => esc_html__( 'Use the variation thumbnail for the Color attribute. The Color slug has to be "color". You need to specify Color for variation (not any)', 'platrxyz' )
		,'default'  => true
		,'required'	=> array( 'platr_prod_attr_color_text', 'equals', '0' )
	)
	,array(
		'id'        => 'platr_prod_next_prev_navigation'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Next/Prev Product Navigation', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_thumbnail'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Thumbnail', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'       	=> 'platr_prod_gallery_layout'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Gallery Layout', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'vertical'		=> esc_html__( 'Vertical', 'platrxyz' )
			,'horizontal'	=> esc_html__( 'Horizontal', 'platrxyz' )
			,'grid'			=> esc_html__( 'Grid', 'platrxyz' )
		)
		,'default'  => 'vertical'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_prod_thumbnails_slider_mobile'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Thumbnails Slider On Mobile', 'platrxyz' )
		,'subtitle' => esc_html__( 'If enabled, it will change all thumbnail/gallery layouts to slider on mobile', 'platrxyz' )
		,'default'  => true
		,'required'	=> array('platr_prod_gallery_layout', 'equals', 'grid')
	)
	,array(
		'id'        => 'platr_prod_group_heading'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Heading For Grouped Product', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show this heading above list of grouped products', 'platrxyz' )
		,'desc'     => ''
		,'default'  => 'Part Of This Collection'
	)
	,array(
		'id'        => 'platr_prod_wfbt_in_summary'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Frequently Bought Together In Summary', 'platrxyz' )
		,'subtitle' => esc_html__( 'Move Frequently Bought Together to product summary in laptop screen & larger', 'platrxyz' )
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_label'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Label', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_title'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Title', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_title_in_content'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Title In Content', 'platrxyz' )
		,'subtitle' => esc_html__( 'Display the product title in the page content instead of above the breadcrumbs', 'platrxyz' )
		,'default'  => true
	)
	,array(
		'id'        => 'platr_prod_rating'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Rating', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_sku'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product SKU', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_availability'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Availability', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_short_desc'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Short Description', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_count_down'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Count Down', 'platrxyz' )
		,'subtitle' => esc_html__( 'You have to activate PlaT plugin', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_price'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Price', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_discount_percent'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Discount Percent', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show discount percent next to the price', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
		,'required'	=> array( 'platr_prod_price', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_add_to_cart'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Add To Cart Button', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_ajax_add_to_cart'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Ajax Add To Cart', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'required'	=> array( 'platr_prod_add_to_cart', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_buy_now'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Buy Now Button', 'platrxyz' )
		,'subtitle' => esc_html__( 'Only support the simple and variable products', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_brand'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Brands', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_cat'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Categories', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_tag'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Tags', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_size_chart'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Size Chart', 'platrxyz' )
		,'subtitle' => esc_html__( 'Size Chart Popup is only available if Attribute Dropdown is disabled and the slug of the Size attribute contain "size". Ex: taille-size', 'platrxyz' )
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_more_less_content'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product More/Less Content', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show more/less content in the Description tab', 'platrxyz' )
		,'default'  => false
	)
	,array(
		'id'        => 'platr_prod_sharing'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Sharing', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_sharing_sharethis'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Sharing - Use ShareThis', 'platrxyz' )
		,'subtitle' => esc_html__( 'Use share buttons from sharethis.com. You need to add key below', 'platrxyz' )
		,'default'  => false
		,'required'	=> array( 'platr_prod_sharing', 'equals', '1' )
	)
	,array(
		'id'        => 'platr_prod_sharing_sharethis_key'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Sharing - ShareThis Key', 'platrxyz' )
		,'subtitle' => esc_html__( 'You get it from script code. It is the value of "property" attribute', 'platrxyz' )
		,'desc'     => ''
		,'default'  => ''
		,'required'	=> array( 'platr_prod_sharing', 'equals', '1' )
	)

	,array(
		'id'        => 'section-product-tabs'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Product Tabs', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_prod_tabs'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Tabs', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'       	=> 'platr_prod_tabs_position'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Tabs Position', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'options'  => array(
			'after_summary'				=> esc_html__( 'After Summary', 'platrxyz' )
			,'inside_summary'			=> esc_html__( 'Inside Summary', 'platrxyz' )
		)
		,'default'  => 'after_summary'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'       	=> 'platr_prod_tabs_accordion'
		,'type'     => 'select'
		,'title'    => esc_html__( 'Product Tabs Accordion', 'platrxyz' )
		,'subtitle' => esc_html__( 'Show tabs as accordion. If you add more custom tabs, please make sure that your tab content has heading (h2) at the top', 'platrxyz' )
		,'desc'     => ''
		,'options'  => array(
			'0'				=> esc_html__( 'None', 'platrxyz' )
			,'desktop'		=> esc_html__( 'On Desktop', 'platrxyz' )
			,'mobile'		=> esc_html__( 'On Mobile', 'platrxyz' )
			,'both'			=> esc_html__( 'On All Screens', 'platrxyz' )
		)
		,'default'  => 'mobile'
		,'select2'	=> array('allowClear' => false, 'minimumResultsForSearch' => 'Infinity')
	)
	,array(
		'id'        => 'platr_prod_custom_tab'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Product Custom Tab', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_custom_tab_title'
		,'type'     => 'text'
		,'title'    => esc_html__( 'Product Custom Tab Title', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => 'Custom tab'
	)
	,array(
		'id'        => 'platr_prod_custom_tab_content'
		,'type'     => 'editor'
		,'title'    => esc_html__( 'Product Custom Tab Content', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => esc_html__( 'Your custom content goes here. You can add the content for individual product', 'platrxyz' )
		,'args'     => array(
			'wpautop'        => false
			,'media_buttons' => true
			,'textarea_rows' => 5
			,'teeny'         => false
			,'quicktags'     => true
		)
	)
	
	,array(
		'id'        => 'section-ads-banner'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Ads Banner', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_prod_ads_banner'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Ads Banner', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_ads_banner_content'
		,'type'     => 'editor'
		,'title'    => esc_html__( 'Ads Banner Content', 'platrxyz' )
		,'subtitle' => ''
		,'desc'     => ''
		,'default'  => ''
		,'args'     => array(
			'wpautop'        => false
			,'media_buttons' => true
			,'textarea_rows' => 5
			,'teeny'         => false
			,'quicktags'     => true
		)
	)
	
	,array(
		'id'        => 'section-related-up-sell-products'
		,'type'     => 'section'
		,'title'    => esc_html__( 'Related - Up-Sell', 'platrxyz' )
		,'subtitle' => ''
		,'indent'   => false
	)
	,array(
		'id'        => 'platr_prod_related'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Related Products', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => true
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
	,array(
		'id'        => 'platr_prod_upsells'
		,'type'     => 'switch'
		,'title'    => esc_html__( 'Up-Sell Products', 'platrxyz' )
		,'subtitle' => ''
		,'default'  => false
		,'on'		=> esc_html__( 'Show', 'platrxyz' )
		,'off'		=> esc_html__( 'Hide', 'platrxyz' )
	)
);

/*** Custom Code Tab ***/
$option_fields['custom-code'] = array(
	array(
		'id'        => 'platr_custom_css_code'
		,'type'     => 'ace_editor'
		,'title'    => esc_html__( 'Custom CSS Code', 'platrxyz' )
		,'subtitle' => ''
		,'mode'     => 'css'
		,'theme'    => 'monokai'
		,'desc'     => ''
		,'default'  => ''
	)
	,array(
		'id'        => 'platr_custom_javascript_code'
		,'type'     => 'ace_editor'
		,'title'    => esc_html__( 'Custom Javascript Code', 'platrxyz' )
		,'subtitle' => ''
		,'mode'     => 'javascript'
		,'theme'    => 'monokai'
		,'desc'     => ''
		,'default'  => ''
	)
);