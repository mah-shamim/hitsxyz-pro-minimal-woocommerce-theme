<?php
if( !isset($data) ){
	$data = platrxyz_get_theme_options();
}

$default_options = array(
				'platr_layout_fullwidth'			=> 0
				,'platr_logo_width'				=> "160"
				,'platr_device_logo_width'			=> "120"
				,'platr_header_slide_notice_timing' => "15"
				,'platr_custom_font_ttf'			=> array( 'url' => '' )
		);
		
foreach( $default_options as $option_name => $value ){
	if( isset($data[$option_name]) ){
		$default_options[$option_name] = $data[$option_name];
	}
}

extract($default_options);
		
$default_colors = array(
				'platr_main_content_background_color'				=>	'#ffffff'
				,'platr_primary_color'								=>	'#d10202'
				,'platr_text_color_in_bg_primary'					=>	'#ffffff'
				,'platr_text_color'								=>	'#000000'
				,'platr_heading_color'								=>	'#000000'
				,'platr_gray_text_color'							=>	'#848484'
				,'platr_gray_bg_color'								=>	'#efefef'
				,'platr_text_in_gray_bg_color'						=>	'#000000'
				,'platr_dropdown_bg_color'							=>	'#ffffff'
				,'platr_dropdown_color'							=>	'#000000'
				,'platr_link_color'								=>	'#d10202'
				,'platr_link_color_hover'							=>	'#848484'
				,'platr_icon_hover_color'							=>	'#d10202'
				,'platr_tags_color'								=>	'#848484'
				,'platr_tags_background_color'						=>	'#ffffff'
				,'platr_tags_border_color'							=>	'#ebebeb'
				,'platr_blockquote_icon_color'						=>	'#959595'
				,'platr_blockquote_text_color'						=>	'#000000'
				,'platr_border_color'								=>	'#ebebeb'
				,'platr_input_text_color'							=>	'#000000'
				,'platr_input_background_color'					=>	'#ffffff'
				,'platr_input_border_color'						=>	'#ebebeb'
				,'platr_button_text_color'							=>	'#ffffff'
				,'platr_button_background_color'					=>	'#000000'
				,'platr_button_border_color'						=>	'#000000'
				,'platr_button_text_hover_color'					=>	'#ffffff'
				,'platr_button_background_hover_color'				=>	'#d10202'
				,'platr_button_border_hover_color'					=>	'#d10202'
				,'platr_button_thumbnail_text_color'				=>	'#000000'
				,'platr_button_thumbnail_bg_color'					=>	'#ffffff'
				,'platr_button_thumbnail_hover_text_color'			=>	'#ffffff'
				,'platr_button_thumbnail_hover_bg_color'			=>	'#d10202'
				,'platr_breadcrumb_background_color'				=>	'#ffffff'
				,'platr_breadcrumb_text_color'						=>	'#000000'
				,'platr_breadcrumb_link_color'						=>	'#848484'
				,'platr_header_top_background_color'				=>	'#000000'
				,'platr_header_top_text_color'						=>	'#ffffff'
				,'platr_header_top_border_color'					=>	'#000000'
				,'platr_header_top_link_hover_color'				=>	'#848484'
				,'platr_header_top_icon_count_background_color'	=>	'#ffffff'
				,'platr_header_top_icon_count_text_color'			=>	'#000000'
				,'platr_header_middle_background_color'			=>	'#ffffff'
				,'platr_header_middle_text_color'					=>	'#000000'
				,'platr_header_middle_border_color'				=>	'#d6d6d6'
				,'platr_header_middle_link_hover_color'			=>	'#848484'
				,'platr_header_icon_count_background_color'		=>	'#000000'
				,'platr_header_icon_count_text_color'				=>	'#ffffff'
				,'platr_header_bottom_background_color'			=>	'#ffffff'
				,'platr_header_bottom_text_color'					=>	'#000000'
				,'platr_header_bottom_border_color'				=>	'#d6d6d6'
				,'platr_header_bottom_link_hover_color'			=>	'#848484'
				,'platr_footer_background_color'					=>	'#ffffff'
				,'platr_footer_text_color'							=>	'#848484'
				,'platr_footer_link_hover_color'					=>	'#d10202'
				,'platr_footer_border_color'						=>	'#d6d6d6'
				,'platr_rating_color'								=>	'#000000'
				,'platr_product_price_color'						=>	'#000000'
				,'platr_product_sale_price_color'					=>	'#848484'
				,'platr_product_sale_label_text_color'				=>	'#ffffff'
				,'platr_product_sale_label_background_color'		=>	'#000000'
				,'platr_product_new_label_text_color'				=>	'#ffffff'
				,'platr_product_new_label_background_color'		=>	'#ffa632'
				,'platr_product_feature_label_text_color'			=>	'#ffffff'
				,'platr_product_feature_label_background_color'	=>	'#d10202'
				,'platr_product_outstock_label_text_color'			=>	'#ffffff'
				,'platr_product_outstock_label_background_color'	=>	'#919191'
				,'platr_product_meta_label_text_color'				=>	'#d10202'
);

$data = apply_filters('platrxyz_custom_style_data', $data);

foreach( $default_colors as $option_name => $default_color ){
	if( isset($data[$option_name]['rgba']) ){
		$default_colors[$option_name] = $data[$option_name]['rgba'];
	}
	else if( isset($data[$option_name]['color']) ){
		$default_colors[$option_name] = $data[$option_name]['color'];
	}
}

extract( $default_colors );

/* Parse font option. Ex: if option name is platr_body_font, we will have variables below:
* platr_body_font (font-family)
* platr_body_font_weight
* platr_body_font_style
* platr_body_font_size
* platr_body_font_line_height
* platr_body_font_letter_spacing
*/
$font_option_names = array(
							'platr_body_font',
							'platr_body_font_medium',
							'platr_body_font_bold',
							'platr_heading_font',
							'platr_menu_font',
							'platr_sidebar_menu_font',
							'platr_mobile_menu_font',
							'platr_button_font',
							);
$font_size_option_names = array( 
							'platr_h1_font', 
							'platr_h2_font', 
							'platr_h3_font', 
							'platr_h4_font', 
							'platr_h5_font', 
							'platr_h6_font',
							'platr_sub_menu_font',
							'platr_sidebar_submenu_font',
							'platr_blockquote_font',
							'platr_single_product_price_font',
							'platr_single_product_sale_price_font',
							'platr_h1_ipad_font', 
							'platr_h2_ipad_font', 
							'platr_h3_ipad_font', 
							'platr_h4_ipad_font',
							'platr_h5_ipad_font',
							'platr_h6_ipad_font',
							'platr_sidebar_menu_ipad_font',
							'platr_sidebar_submenu_ipad_font',
							'platr_single_product_price_ipad_font',
							'platr_single_product_sale_price_ipad_font',
							'platr_h1_mobile_font',
							'platr_h2_mobile_font',
							'platr_h3_mobile_font',
							'platr_h4_mobile_font',
							'platr_h5_mobile_font',
							'platr_h6_mobile_font',
							);
$font_option_names = array_merge($font_option_names, $font_size_option_names);
foreach( $font_option_names as $option_name ){
	$default = array(
		$option_name 						=> 'inherit'
		,$option_name . '_weight' 			=> 'normal'
		,$option_name . '_style' 			=> 'normal'
		,$option_name . '_size' 			=> 'inherit'
		,$option_name . '_line_height' 		=> 'inherit'
		,$option_name . '_letter_spacing' 	=> 'inherit'
		,$option_name . '_transform' 		=> 'inherit'
	);
	if( is_array($data[$option_name]) ){
		if( !empty($data[$option_name]['font-family']) ){
			$default[$option_name] = $data[$option_name]['font-family'];
		}
		if( !empty($data[$option_name]['font-weight']) ){
			$default[$option_name . '_weight'] = $data[$option_name]['font-weight'];
		}
		if( !empty($data[$option_name]['font-style']) ){
			$default[$option_name . '_style'] = $data[$option_name]['font-style'];
		}
		if( !empty($data[$option_name]['font-size']) ){
			$default[$option_name . '_size'] = $data[$option_name]['font-size'];
		}
		if( !empty($data[$option_name]['line-height']) ){
			$default[$option_name . '_line_height'] = $data[$option_name]['line-height'];
		}
		if( !empty($data[$option_name]['letter-spacing']) ){
			$default[$option_name . '_letter_spacing'] = $data[$option_name]['letter-spacing'];
		}
		if( !empty($data[$option_name]['text-transform']) ){
			$default[$option_name . '_transform'] = $data[$option_name]['text-transform'];
		}
	}
	extract( $default );
}

/* Custom Font */
if( isset($platr_custom_font_ttf) && $platr_custom_font_ttf['url'] ): ?>
@font-face {
	font-family: <?php echo esc_html($ts_custom_font_ttf['name']); ?>;
	src:url('<?php echo esc_url($platr_custom_font_ttf['url']); ?>') format('truetype');
	font-weight: normal;
	font-style: normal;
}
<?php endif; ?>	
	
:root{
	--platrxyz-logo-width: <?php echo absint($platr_logo_width); ?>px;
	--platrxyz-logo-device-width: <?php echo absint($platr_device_logo_width); ?>px;
	
	<?php if( $platr_header_slide_notice_timing ): ?>
	--platrxyz-marquee-timing: <?php echo esc_html($platr_header_slide_notice_timing); ?>s;
	<?php endif; ?>
	
	--platrxyz-main-font-family: <?php echo esc_html($platr_body_font); ?>;
	--platrxyz-main-font-style: <?php echo esc_html($platr_body_font_style); ?>;
	--platrxyz-main-font-weight: <?php echo esc_html($platr_body_font_weight); ?>;
	--platrxyz-main-font-medium-family: <?php echo esc_html($platr_body_font_medium); ?>;
	--platrxyz-main-font-medium-style: <?php echo esc_html($platr_body_font_medium_style); ?>;
	--platrxyz-main-font-medium-weight: <?php echo esc_html($platr_body_font_medium_weight); ?>;
	--platrxyz-main-font-bold-family: <?php echo esc_html($platr_body_font_bold); ?>;
	--platrxyz-main-font-bold-style: <?php echo esc_html($platr_body_font_bold_style); ?>;
	--platrxyz-main-font-bold-weight: <?php echo esc_html($platr_body_font_bold_weight); ?>;
	--platrxyz-body-font-size: <?php echo esc_html($platr_body_font_size); ?>;
	--platrxyz-body-line-height: <?php echo esc_html($platr_body_font_line_height); ?>;
	--platrxyz-body-letter-spacing: <?php echo esc_html($platr_body_font_letter_spacing); ?>;
	
	--platrxyz-button-font-family: <?php echo esc_html($platr_button_font); ?>;
	--platrxyz-button-font-style: <?php echo esc_html($platr_button_font_style); ?>;
	--platrxyz-button-font-weight: <?php echo esc_html($platr_button_font_weight); ?>;
	--platrxyz-button-transform: <?php echo esc_html($platr_button_font_transform); ?>;
	--platrxyz-button-font-size: <?php echo esc_html($platr_button_font_size); ?>;
	--platrxyz-button-letter-spacing: <?php echo esc_html($platr_button_font_letter_spacing); ?>;
	
	--platrxyz-menu-font-family: <?php echo esc_html($platr_menu_font); ?>;
	--platrxyz-menu-font-style: <?php echo esc_html($platr_menu_font_style); ?>;
	--platrxyz-menu-font-weight: <?php echo esc_html($platr_menu_font_weight); ?>;
	--platrxyz-menu-font-size: <?php echo esc_html($platr_menu_font_size); ?>;
	--platrxyz-menu-line-height: <?php echo esc_html($platr_menu_font_line_height); ?>;
	--platrxyz-submenu-font-size: <?php echo esc_html($platr_sub_menu_font_size); ?>;
	--platrxyz-submenu-line-height: <?php echo esc_html($platr_sub_menu_font_line_height); ?>;
	
	--platrxyz-sidebar-menu-font-family: <?php echo esc_html($platr_sidebar_menu_font); ?>;
	--platrxyz-sidebar-menu-font-style: <?php echo esc_html($platr_sidebar_menu_font_style); ?>;
	--platrxyz-sidebar-menu-font-weight: <?php echo esc_html($platr_sidebar_menu_font_weight); ?>;
	--platrxyz-sidebar-menu-font-size: <?php echo esc_html($platr_sidebar_menu_font_size); ?>;
	--platrxyz-sidebar-menu-line-height: <?php echo esc_html($platr_sidebar_menu_font_line_height); ?>;
	--platrxyz-sidebar-submenu-font-size: <?php echo esc_html($platr_sidebar_submenu_font_size); ?>;
	--platrxyz-sidebar-submenu-line-height: <?php echo esc_html($platr_sidebar_submenu_font_line_height); ?>;
	--platrxyz-sidebar-menu-ipad-font-size: <?php echo esc_html($platr_sidebar_menu_ipad_font_size); ?>;
	--platrxyz-sidebar-menu-ipad-line-height: <?php echo esc_html($platr_sidebar_menu_ipad_font_line_height); ?>;
	--platrxyz-sidebar-submenu-ipad-font-size: <?php echo esc_html($platr_sidebar_submenu_ipad_font_size); ?>;
	--platrxyz-sidebar-submenu-ipad-line-height: <?php echo esc_html($platr_sidebar_submenu_ipad_font_line_height); ?>;
	
	--platrxyz-mobile-menu-font-family: <?php echo esc_html($platr_sidebar_menu_font); ?>;
	--platrxyz-mobile-menu-font-style: <?php echo esc_html($platr_sidebar_menu_font_style); ?>;
	--platrxyz-mobile-menu-font-weight: <?php echo esc_html($platr_sidebar_menu_font_weight); ?>;
	--platrxyz-mobile-menu-font-size: <?php echo esc_html($platr_mobile_menu_font_size); ?>;
	--platrxyz-mobile-menu-line-height: <?php echo esc_html($platr_mobile_menu_font_line_height); ?>;
	
	--platrxyz-blockquote-font-size: <?php echo esc_html($platr_blockquote_font_size); ?>;
	--platrxyz-single-product-price-font-size: <?php echo esc_html($platr_single_product_price_font_size); ?>;
	--platrxyz-single-product-sale-price-font-size: <?php echo esc_html($platr_single_product_sale_price_font_size); ?>;
	--platrxyz-single-product-price-ipad-font-size: <?php echo esc_html($platr_single_product_price_ipad_font_size); ?>;
	--platrxyz-single-product-sale-price-ipad-font-size: <?php echo esc_html($platr_single_product_sale_price_ipad_font_size); ?>;
	
	--platrxyz-heading-font-family: <?php echo esc_html($platr_heading_font); ?>;
	--platrxyz-heading-font-style: <?php echo esc_html($platr_heading_font_style); ?>;
	--platrxyz-heading-font-weight: <?php echo esc_html($platr_heading_font_weight); ?>;
	--platrxyz-h1-font-size: <?php echo esc_html($platr_h1_font_size); ?>;
	--platrxyz-h1-line-height: <?php echo esc_html($platr_h1_font_line_height); ?>;
	--platrxyz-h1-letter-spacing: <?php echo esc_html($platr_h1_font_letter_spacing); ?>;
	--platrxyz-h2-font-size: <?php echo esc_html($platr_h2_font_size); ?>;
	--platrxyz-h2-line-height: <?php echo esc_html($platr_h2_font_line_height); ?>;
	--platrxyz-h2-letter-spacing: <?php echo esc_html($platr_h2_font_letter_spacing); ?>;
	--platrxyz-h3-font-size: <?php echo esc_html($platr_h3_font_size); ?>;
	--platrxyz-h3-line-height: <?php echo esc_html($platr_h3_font_line_height); ?>;
	--platrxyz-h3-letter-spacing: <?php echo esc_html($platr_h3_font_letter_spacing); ?>;
	--platrxyz-h4-font-size: <?php echo esc_html($platr_h4_font_size); ?>;
	--platrxyz-h4-line-height: <?php echo esc_html($platr_h4_font_line_height); ?>;
	--platrxyz-h4-letter-spacing: <?php echo esc_html($platr_h4_font_letter_spacing); ?>;
	--platrxyz-h5-font-size: <?php echo esc_html($platr_h5_font_size); ?>;
	--platrxyz-h5-line-height: <?php echo esc_html($platr_h5_font_line_height); ?>;
	--platrxyz-h5-letter-spacing: <?php echo esc_html($platr_h5_font_letter_spacing); ?>;
	--platrxyz-h6-font-size: <?php echo esc_html($platr_h6_font_size); ?>;
	--platrxyz-h6-line-height: <?php echo esc_html($platr_h6_font_line_height); ?>;
	--platrxyz-h6-letter-spacing: <?php echo esc_html($platr_h6_font_letter_spacing); ?>;
	--platrxyz-h1-ipad-font-size: <?php echo esc_html($platr_h1_ipad_font_size); ?>;
	--platrxyz-h1-ipad-line-height: <?php echo esc_html($platr_h1_ipad_font_line_height); ?>;
	--platrxyz-h1-ipad-letter-spacing: <?php echo esc_html($platr_h1_ipad_font_letter_spacing); ?>;
	--platrxyz-h2-ipad-font-size: <?php echo esc_html($platr_h2_ipad_font_size); ?>;
	--platrxyz-h2-ipad-line-height: <?php echo esc_html($platr_h2_ipad_font_line_height); ?>;
	--platrxyz-h2-ipad-letter-spacing: <?php echo esc_html($platr_h2_ipad_font_letter_spacing); ?>;
	--platrxyz-h3-ipad-font-size: <?php echo esc_html($platr_h3_ipad_font_size); ?>;
	--platrxyz-h3-ipad-line-height: <?php echo esc_html($platr_h3_ipad_font_line_height); ?>;
	--platrxyz-h3-ipad-letter-spacing: <?php echo esc_html($platr_h3_ipad_font_letter_spacing); ?>;
	--platrxyz-h4-ipad-font-size: <?php echo esc_html($platr_h4_ipad_font_size); ?>;
	--platrxyz-h4-ipad-line-height: <?php echo esc_html($platr_h4_ipad_font_line_height); ?>;
	--platrxyz-h4-ipad-letter-spacing: <?php echo esc_html($platr_h4_ipad_font_letter_spacing); ?>;
	--platrxyz-h5-ipad-font-size: <?php echo esc_html($platr_h5_ipad_font_size); ?>;
	--platrxyz-h5-ipad-line-height: <?php echo esc_html($platr_h5_ipad_font_line_height); ?>;
	--platrxyz-h5-ipad-letter-spacing: <?php echo esc_html($platr_h5_ipad_font_letter_spacing); ?>;
	--platrxyz-h6-ipad-font-size: <?php echo esc_html($platr_h6_ipad_font_size); ?>;
	--platrxyz-h6-ipad-line-height: <?php echo esc_html($platr_h6_ipad_font_line_height); ?>;
	--platrxyz-h6-ipad-letter-spacing: <?php echo esc_html($platr_h6_ipad_font_letter_spacing); ?>;
	--platrxyz-h1-mobile-font-size: <?php echo esc_html($platr_h1_mobile_font_size); ?>;
	--platrxyz-h1-mobile-line-height: <?php echo esc_html($platr_h1_mobile_font_line_height); ?>;
	--platrxyz-h1-mobile-letter-spacing: <?php echo esc_html($platr_h1_mobile_font_letter_spacing); ?>;
	--platrxyz-h2-mobile-font-size: <?php echo esc_html($platr_h2_mobile_font_size); ?>;
	--platrxyz-h2-mobile-line-height: <?php echo esc_html($platr_h2_mobile_font_line_height); ?>;
	--platrxyz-h2-mobile-letter-spacing: <?php echo esc_html($platr_h2_mobile_font_letter_spacing); ?>;
	--platrxyz-h3-mobile-font-size: <?php echo esc_html($platr_h3_mobile_font_size); ?>;
	--platrxyz-h3-mobile-line-height: <?php echo esc_html($platr_h3_mobile_font_line_height); ?>;
	--platrxyz-h3-mobile-letter-spacing: <?php echo esc_html($platr_h3_mobile_font_letter_spacing); ?>;
	--platrxyz-h4-mobile-font-size: <?php echo esc_html($platr_h4_mobile_font_size); ?>;
	--platrxyz-h4-mobile-line-height: <?php echo esc_html($platr_h4_mobile_font_line_height); ?>;
	--platrxyz-h4-mobile-letter-spacing: <?php echo esc_html($platr_h4_mobile_font_letter_spacing); ?>;
	--platrxyz-h5-mobile-font-size: <?php echo esc_html($platr_h5_mobile_font_size); ?>;
	--platrxyz-h5-mobile-line-height: <?php echo esc_html($platr_h5_mobile_font_line_height); ?>;
	--platrxyz-h5-mobile-letter-spacing: <?php echo esc_html($platr_h5_mobile_font_letter_spacing); ?>;
	--platrxyz-h6-mobile-font-size: <?php echo esc_html($platr_h6_mobile_font_size); ?>;
	--platrxyz-h6-mobile-line-height: <?php echo esc_html($platr_h6_mobile_font_line_height); ?>;
	--platrxyz-h6-mobile-letter-spacing: <?php echo esc_html($platr_h6_mobile_font_letter_spacing); ?>;
	
	--platrxyz-primary-color: <?php echo esc_html($platr_primary_color); ?>;
	--platrxyz-text-in-primary-color: <?php echo esc_html($platr_text_color_in_bg_primary); ?>;
	<?php if( strpos($platr_primary_color, 'rgba') !== false ): ?>
	--platrxyz-primary-loading-color: <?php echo esc_html(str_replace('1)', '0.5)', esc_html($platr_primary_color))); ?>;
	<?php endif; ?>
	--platrxyz-main-bg: <?php echo esc_html($platr_main_content_background_color); ?>;
	--platrxyz-text-color: <?php echo esc_html($platr_text_color); ?>;
	--platrxyz-heading-color: <?php echo esc_html($platr_heading_color); ?>;
	--platrxyz-gray-color: <?php echo esc_html($platr_gray_text_color); ?>;
	--platrxyz-gray-bg: <?php echo esc_html($platr_gray_bg_color); ?>;
	--platrxyz-text-in-gray-bg: <?php echo esc_html($platr_text_in_gray_bg_color); ?>;
	--platrxyz-dropdown-bg: <?php echo esc_html($platr_dropdown_bg_color); ?>;
	--platrxyz-dropdown-color: <?php echo esc_html($platr_dropdown_color); ?>;
	--platrxyz-link-color: <?php echo esc_html($platr_link_color); ?>;
	--platrxyz-link-hover-color: <?php echo esc_html($platr_link_color_hover); ?>;
	--platrxyz-icon-hover-color: <?php echo esc_html($platr_icon_hover_color); ?>;
	--platrxyz-tag-color: <?php echo esc_html($platr_tags_color); ?>;
	--platrxyz-tag-bg: <?php echo esc_html($platr_tags_background_color); ?>;
	--platrxyz-tag-border: <?php echo esc_html($platr_tags_border_color); ?>;
	--platrxyz-blockquote-icon-color: <?php echo esc_html($platr_blockquote_icon_color); ?>;
	--platrxyz-blockquote-text-color: <?php echo esc_html($platr_blockquote_text_color); ?>;
	--platrxyz-border: <?php echo esc_html($platr_border_color); ?>;
	
	--platrxyz-input-color: <?php echo esc_html($platr_input_text_color); ?>;
	--platrxyz-input-background-color: <?php echo esc_html($platr_input_background_color); ?>;
	--platrxyz-input-border: <?php echo esc_html($platr_input_border_color); ?>;
	
	--platrxyz-button-color: <?php echo esc_html($platr_button_text_color); ?>;
	--platrxyz-button-bg: <?php echo esc_html($platr_button_background_color); ?>;
	--platrxyz-button-border: <?php echo esc_html($platr_button_border_color); ?>;
	--platrxyz-button-hover-color: <?php echo esc_html($platr_button_text_hover_color); ?>;
	--platrxyz-button-hover-bg: <?php echo esc_html($platr_button_background_hover_color); ?>;
	--platrxyz-button-hover-border: <?php echo esc_html($platr_button_border_hover_color); ?>;
	<?php if( strpos($platr_button_text_color, 'rgba') !== false ): ?>
	--platrxyz-button-loading-color: <?php echo esc_html(str_replace('1)', '0.5)', esc_html($platr_button_text_color))); ?>;
	<?php endif; ?>
	<?php if( strpos($platr_button_text_hover_color, 'rgba') !== false ): ?>
	--platrxyz-button-loading-hover-color: <?php echo esc_html(str_replace('1)', '0.5)', esc_html($platr_button_text_hover_color))); ?>;
	<?php endif; ?>
	--platrxyz-button-thumbnail-color: <?php echo esc_html($platr_button_thumbnail_text_color); ?>;
	--platrxyz-button-thumbnail-bg: <?php echo esc_html($platr_button_thumbnail_bg_color); ?>;
	--platrxyz-button-thumbnail-hover-color: <?php echo esc_html($platr_button_thumbnail_hover_text_color); ?>;
	--platrxyz-button-thumbnail-hover-bg: <?php echo esc_html($platr_button_thumbnail_hover_bg_color); ?>;
	<?php if( strpos($platr_button_thumbnail_text_color, 'rgba') !== false ): ?>
	--platrxyz-button-thumbnail-loading-color: <?php echo esc_html(str_replace('1)', '0.5)', esc_html($platr_button_thumbnail_text_color))); ?>;
	<?php endif; ?>
	<?php if( strpos($platr_button_thumbnail_hover_text_color, 'rgba') !== false ): ?>
	--platrxyz-button-thumbnail-loading-hover-color: <?php echo esc_html(str_replace('1)', '0.5)', esc_html($platr_button_thumbnail_hover_text_color))); ?>;
	<?php endif; ?>
	
	--platrxyz-breadcrumb-bg: <?php echo esc_html($platr_breadcrumb_background_color); ?>;
	--platrxyz-breadcrumb-color: <?php echo esc_html($platr_breadcrumb_text_color); ?>;
	--platrxyz-breadcrumb-link-color: <?php echo esc_html($platr_breadcrumb_link_color); ?>;
	
	--platrxyz-top-bg: <?php echo esc_html($platr_header_top_background_color); ?>;
	--platrxyz-top-color: <?php echo esc_html($platr_header_top_text_color); ?>;
	--platrxyz-top-border: <?php echo esc_html($platr_header_top_border_color); ?>;
	--platrxyz-top-link-hover-color: <?php echo esc_html($platr_header_top_link_hover_color); ?>;
	--platrxyz-top-cart-number-bg: <?php echo esc_html($platr_header_top_icon_count_background_color); ?>;
	--platrxyz-top-cart-number-color: <?php echo esc_html($platr_header_top_icon_count_text_color); ?>;
	--platrxyz-middle-bg: <?php echo esc_html($platr_header_middle_background_color); ?>;
	--platrxyz-middle-color: <?php echo esc_html($platr_header_middle_text_color); ?>;
	--platrxyz-middle-border: <?php echo esc_html($platr_header_middle_border_color); ?>;
	--platrxyz-middle-link-hover-color: <?php echo esc_html($platr_header_middle_link_hover_color); ?>;
	--platrxyz-middle-cart-number-bg: <?php echo esc_html($platr_header_icon_count_background_color); ?>;
	--platrxyz-middle-cart-number-color: <?php echo esc_html($platr_header_icon_count_text_color); ?>;
	--platrxyz-bottom-bg: <?php echo esc_html($platr_header_bottom_background_color); ?>;
	--platrxyz-bottom-color: <?php echo esc_html($platr_header_bottom_text_color); ?>;
	--platrxyz-bottom-border: <?php echo esc_html($platr_header_bottom_border_color); ?>;
	--platrxyz-bottom-link-hover-color: <?php echo esc_html($platr_header_bottom_link_hover_color); ?>;
	
	--platrxyz-footer-bg: <?php echo esc_html($platr_footer_background_color); ?>;
	--platrxyz-footer-color: <?php echo esc_html($platr_footer_text_color); ?>;
	--platrxyz-footer-link-color: <?php echo esc_html($platr_footer_link_hover_color); ?>;
	--platrxyz-footer-border: <?php echo esc_html($platr_footer_border_color); ?>;
	
	--platrxyz-star-color: <?php echo esc_html($platr_rating_color); ?>;
	--platrxyz-product-price-color: <?php echo esc_html($platr_product_price_color); ?>;
	--platrxyz-product-sale-price-color: <?php echo esc_html($platr_product_sale_price_color); ?>;
	--platrxyz-sale-label-color: <?php echo esc_html($platr_product_sale_label_text_color); ?>;
	--platrxyz-sale-label-bg: <?php echo esc_html($platr_product_sale_label_background_color); ?>;
	--platrxyz-new-label-color: <?php echo esc_html($platr_product_new_label_text_color); ?>;
	--platrxyz-new-label-bg: <?php echo esc_html($platr_product_new_label_background_color); ?>;
	--platrxyz-hot-label-color: <?php echo esc_html($platr_product_feature_label_text_color); ?>;
	--platrxyz-hot-label-bg: <?php echo esc_html($platr_product_feature_label_background_color); ?>;
	--platrxyz-soldout-label-color: <?php echo esc_html($platr_product_outstock_label_text_color); ?>;
	--platrxyz-soldout-label-bg: <?php echo esc_html($platr_product_outstock_label_background_color); ?>;
	--platrxyz-meta-label-color: <?php echo esc_html($platr_product_meta_label_text_color); ?>;
}