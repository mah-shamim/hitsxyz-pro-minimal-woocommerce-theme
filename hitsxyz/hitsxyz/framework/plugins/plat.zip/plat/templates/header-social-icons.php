<?php 
$theme_options = platrxyz_get_theme_options();
$facebook_url = $theme_options['platr_facebook_url'];
$x_url = $theme_options['platr_x_url'];
$youtube_url = $theme_options['platr_youtube_url'];
$instagram_url = $theme_options['platr_instagram_url'];
$pinterest_url = $theme_options['platr_pinterest_url'];
$linkedin_url = $theme_options['platr_linkedin_url'];
$custom_url = $theme_options['platr_custom_social_url'];
$custom_class = $theme_options['platr_custom_social_class'];
$custom_text = '';
?>
<div class="social-icons">
	<ul>
		<?php do_action('platr_header_social_icons_before'); ?>
			
		<?php if( $facebook_url ): ?>
		<li class="tb-icon-brand-facebook">
			<a href="<?php echo esc_url($facebook_url); ?>" ><?php esc_html_e('Facebook', 'plat'); ?></a>
		</li>
		<?php endif; ?>

		<?php if( $x_url ): ?>
		<li class="tb-icon-brand-x">
			<a href="<?php echo esc_url($x_url); ?>" ><?php esc_html_e('X', 'plat'); ?></a>
		</li>
		<?php endif; ?>
		
		<?php if( $instagram_url ): ?>
		<li class="tb-icon-brand-instagram">
			<a href="<?php echo esc_url($instagram_url); ?>" ><?php esc_html_e('Instagram', 'plat'); ?></a>
		</li>
		<?php endif; ?>
		
		<?php if( $pinterest_url ): ?>
		<li class="tb-icon-brand-pinterest">
			<a href="<?php echo esc_url($pinterest_url); ?>" ><?php esc_html_e('Pinterest', 'plat'); ?></a>
		</li>
		<?php endif; ?>
		
		<?php if( $youtube_url ): ?>
		<li class="tb-icon-brand-youtube">
			<a href="<?php echo esc_url($youtube_url); ?>" ><?php esc_html_e('Youtube', 'plat'); ?></a>
		</li>
		<?php endif; ?>
		
		<?php if( $linkedin_url ): ?>
		<li class="tb-icon-brand-linkedin">
			<a href="<?php echo esc_url($linkedin_url); ?>" ><?php esc_html_e('LinkedIn', 'plat'); ?></a>
		</li>
		<?php endif; ?>
		
		<?php if( $custom_url ): ?>
		<li class="<?php echo esc_attr($custom_class) ?>">
			<a href="<?php echo esc_url($custom_url); ?>" ><?php echo esc_html($custom_text); ?></a>
		</li>
		<?php endif; ?>
		
		<?php do_action('platr_header_social_icons_after'); ?>
	</ul>
</div>