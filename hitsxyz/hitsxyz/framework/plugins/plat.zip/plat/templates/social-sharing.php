<div class="platr-social-sharing">
	<span><?php esc_html_e('Share ', 'plat'); ?></span>
	<ul>
		<li class="facebook">
			<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url(get_permalink()); ?>" target="_blank"><i class="tb-icon-brand-facebook"></i></a>
		</li>
		<li class="x">
			<a href="https://x.com/intent/tweet?text=<?php echo esc_url(get_permalink()); ?>" target="_blank"><i class="tb-icon-brand-x"></i></a>
		</li>
		
		<li class="pinterest">
			<?php $image_link = wp_get_attachment_url( get_post_thumbnail_id() );?>
			<a href="https://pinterest.com/pin/create/button/?url=<?php echo esc_url(get_permalink()); ?>&amp;media=<?php echo esc_url($image_link);?>" target="_blank"><i class="tb-icon-brand-pinterest"></i></a>
		</li>
	</ul>
</div>