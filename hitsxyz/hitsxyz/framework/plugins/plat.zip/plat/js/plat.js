jQuery(function ($) {
	"use strict";

	platr_register_carousel(null, $);

	/*** Load Products In Category Tab ***/
	var platr_product_in_category_tab_data = [];

	/* Change tab */
	$('.platr-product-in-category-tab-wrapper .column-tabs .tab-item, .platr-product-in-product-type-tab-wrapper .column-tabs .tab-item').on('click', function () {
		var element = $(this).parents('.platr-product-in-category-tab-wrapper');
		var is_product_type_tab = false;
		if (element.length == 0) {
			element = $(this).parents('.platr-product-in-product-type-tab-wrapper');
			is_product_type_tab = true;
		}

		var element_top = element.offset().top;
		if (element_top > $(window).scrollTop()) {
			var admin_bar_height = $('#wpadminbar').length > 0 ? $('#wpadminbar').outerHeight() : 0;
			var sticky_height = $('.is-sticky .header-sticky').length > 0 ? $('.is-sticky .header-sticky').outerHeight() : 0;
			$('body, html').animate({
				scrollTop: element_top - sticky_height - admin_bar_height - 20
			}, 500);
		}

		if ($(this).hasClass('current') || element.find('.column-products').hasClass('loading')) {
			return;
		}

		element.removeClass('generated-slider');

		var element_id = element.attr('id');
		var atts = element.data('atts');
		if (!is_product_type_tab) {
			var product_cat = $(this).data('product_cat');
			var shop_more_link = $(this).data('link');
			var is_general_tab = $(this).hasClass('general-tab') ? 1 : 0;
		}
		else {
			var product_cat = atts.product_cats;
			var is_general_tab = 0;
			atts.product_type = $(this).data('product_type');
			element.find('.column-products').removeClass('recent sale featured best_selling top_rated mixed_order').addClass(atts.product_type);
			element.find('.shop-more').attr('style', 'display: none');
			$('.shop-more.' + $(this).data('id')).attr('style', '');
		}

		if (!is_product_type_tab && element.find('a.shop-more-button').length > 0) {
			element.find('a.shop-more-button').attr('href', shop_more_link);
		}

		element.find('.column-tabs .tab-item').removeClass('current');
		$(this).addClass('current');

		/* Check cache */
		var tab_data_index = element_id + '-' + product_cat.toString().split(',').join('-');
		if (is_product_type_tab) {
			tab_data_index += '-' + atts.product_type;
		}
		if (platr_product_in_category_tab_data[tab_data_index] != undefined) {
			element.find('.column-products .products').remove();
			element.find('.column-products').append(platr_product_in_category_tab_data[tab_data_index]).hide().fadeIn(600);

			/* Shop more button handle */
			if (!is_product_type_tab) {
				platr_product_in_category_tab_shop_more_handle(element, atts);
			}

			/* Generate slider */
			platr_register_carousel(element.parent(), $);

			return;
		}

		element.find('.column-products').addClass('loading');

		$.ajax({
			type: "POST",
			timeout: 30000,
			url: plat_params.ajax_uri,
			data: { action: 'platr_get_product_content_in_category_tab', atts: atts, product_cat: product_cat, is_general_tab: is_general_tab },
			error: function (xhr, err) {

			},
			success: function (response) {
				if (response) {
					element.find('.column-products .products').remove();
					element.find('.column-products').append(response).hide().fadeIn(600);
					/* save cache */
					if (element.find('.counter-wrapper').length == 0) {
						platr_product_in_category_tab_data[tab_data_index] = response;
					}
					else {
						platr_counter(element.find('.counter-wrapper'));
					}
					/* Shop more button handle */
					if (!is_product_type_tab) {
						platr_product_in_category_tab_shop_more_handle(element, atts);
					}
					/* Generate slider */
					platr_register_carousel(element.parent(), $);
				}

				element.find('.column-products').removeClass('loading');

			}
		});
	});

	function platr_product_in_category_tab_shop_more_handle(element, atts) {
		var hide_shop_more = element.find('.hide-shop-more').length;
		element.find('.hide-shop-more').remove();

		if (element.find('.tab-item.current').hasClass('general-tab') && atts.show_shop_more_general_tab == 0) {
			hide_shop_more = true;
		}

		if (element.find('.products .product').length == 0) {
			hide_shop_more = true;
		}

		if (atts.show_shop_more_button == 1) {
			if (hide_shop_more) {
				element.find('.shop-more').addClass('hidden');
				element.removeClass('has-shop-more-button');
			}
			else {
				element.find('.shop-more').removeClass('hidden');
				element.addClass('has-shop-more-button');
			}
		}
	}

	$('.platr-product-in-category-tab-wrapper').each(function () {
		var element = $(this);
		var atts = element.data('atts');
		platr_product_in_category_tab_shop_more_handle(element, atts);
	});

	setTimeout(function () {
		/*** Blog Shortcode ***/
		$('.platr-blogs-wrapper.platr-shortcode').each(function () {
			var element = $(this);
			var atts = element.data('atts');

			var is_masonry = typeof $.fn.isotope == 'function' && element.hasClass('platr-masonry') ? true : false;

			/* Show more */
			element.find('a.load-more').on('click', function () {
				var button = $(this);
				if (button.hasClass('loading')) {
					return false;
				}

				button.addClass('loading');
				var paged = button.attr('data-paged');
				var total_pages = button.attr('data-total_pages');
				var posts_per_page = button.attr('data-posts_per_page');

				$.ajax({
					type: "POST",
					timeout: 30000,
					url: plat_params.ajax_uri,
					data: { action: 'platr_blogs_load_items', paged: paged, atts: atts },
					error: function (xhr, err) {

					},
					success: function (response) {
						if (paged == total_pages) {
							button.parent().remove();
						}
						else {
							button.removeClass('loading');
							button.prev().find('span').html(paged * posts_per_page);
							button.attr('data-paged', ++paged);
						}
						if (response != 0 && response != '') {
							if (is_masonry) {
								element.find('.blogs').isotope('insert', $(response));
								setTimeout(function () {
									element.find('.blogs').isotope('layout');
								}, 500);
							}
							else {
								element.find('.blogs').append(response);
							}

							platr_register_carousel(element.parent(), $);
						}
						else { /* No results */
							button.parent().remove();
						}
					}
				});

				return false;
			});
		});

	}, 200);

	/*** Counter ***/
	function platr_counter(elements) {
		if (elements.length > 0) {
			var interval = setInterval(function () {
				elements.each(function (index, element) {
					var wrapper = jQuery(element);
					var second = parseInt(wrapper.find('.seconds .number').text());
					if (second > 0) {
						second--;
						second = (second < 10) ? zeroise(second, 2) : second.toString();
						wrapper.find('.seconds .number').text(second);
						return;
					}

					var delta = 0;
					var time_day = 60 * 60 * 24;
					var time_hour = 60 * 60;
					var time_minute = 60;

					var day = parseInt(wrapper.find('.days .number').text());
					var hour = parseInt(wrapper.find('.hours .number').text());
					var minute = parseInt(wrapper.find('.minutes .number').text());

					if (day != 0 || hour != 0 || minute != 0 || second != 0) {
						delta = (day * time_day) + (hour * time_hour) + (minute * time_minute) + second;
						delta--;

						day = Math.floor(delta / time_day);
						delta -= day * time_day;

						hour = Math.floor(delta / time_hour);
						delta -= hour * time_hour;

						minute = Math.floor(delta / time_minute);
						delta -= minute * time_minute;

						second = delta > 0 ? delta : 0;

						day = (day < 10) ? zeroise(day, 2) : day.toString();
						hour = (hour < 10) ? zeroise(hour, 2) : hour.toString();
						minute = (minute < 10) ? zeroise(minute, 2) : minute.toString();
						second = (second < 10) ? zeroise(second, 2) : second.toString();

						wrapper.find('.days .number').text(day);
						wrapper.find('.hours .number').text(hour);
						wrapper.find('.minutes .number').text(minute);
						wrapper.find('.seconds .number').text(second);
					}
				});
			}, 1000);
		}
	}

	platr_counter($('.product .counter-wrapper, .platr-countdown .counter-wrapper'));

	/*** Product Categories Tabs ***/
	$('.platr-product-category-wrapper .tabs .tab-item').on('click', function(){
		var tab_key = $(this).data('tab_key');
		var category_wrapper = $(this).parent().siblings();
		$(this).addClass('active').siblings().removeClass('active');
		category_wrapper.find('.product-category').removeClass('active');
		category_wrapper.find('.product-category.' + tab_key).addClass('active');
	});
	
	/*** Widgets ***/
	/* Custom WP Widget Categories Dropdown */
	$('.widget_categories > ul').each(function (index, ele) {
		var _this = $(ele);
		var icon_toggle_html = '<span class="icon-toggle"></span>';
		var ul_child = _this.find('ul.children');
		ul_child.hide();
		ul_child.closest('li').addClass('cat-parent');
		ul_child.before(icon_toggle_html);
	});

	$('.widget_categories span.icon-toggle').on('click', function () {
		var parent_li = $(this).parent('li.cat-parent');
		if (!parent_li.hasClass('active')) {
			parent_li.find('ul.children:first').slideDown();
			parent_li.addClass('active');
		}
		else {
			parent_li.find('ul.children').slideUp();
			parent_li.removeClass('active');
			parent_li.find('li.cat-parent').removeClass('active');
		}
	});

	$('.widget_categories li.current-cat').parents('ul.children').siblings('.icon-toggle').trigger('click');
	$('.widget_categories li.current-cat.cat-parent > .icon-toggle').trigger('click');

	/* Product Categories widget */
	$('.platr-product-categories-widget .icon-toggle').on('click', function () {
		var parent_li = $(this).parent('li.cat-parent');
		if (!parent_li.hasClass('active')) {
			parent_li.addClass('active');
			parent_li.find('ul.children:first').slideDown();
		}
		else {
			parent_li.find('ul.children').slideUp();
			parent_li.removeClass('active');
			parent_li.find('li.cat-parent').removeClass('active');
		}
	});

	$('.platr-product-categories-widget').each(function () {
		var element = $(this);
		element.find('ul.children').parent('li').addClass('cat-parent');
		element.find('li.current.cat-parent > .icon-toggle').trigger('click');
		element.find('li.current').parents('ul.children').siblings('.icon-toggle').trigger('click');
	});

	/* Product Filter By Availability */
	$('.product-filter-by-availability-wrapper > ul input[type="checkbox"]').on('change', function () {
		$(this).parent('li').siblings('li').find('input[type="checkbox"]').attr('checked', false);
		var val = '';
		if ($(this).is(':checked')) {
			val = $(this).val();
		}
		var form = $(this).closest('ul').siblings('form');
		if (val != '') {
			form.find('input[name="stock"]').val(val);
		}
		else {
			form.find('input[name="stock"]').remove();
		}
		form.submit();
	});

	/* Product Filter By Price */
	$('.product-filter-by-price-wrapper li').on('click', function () {
		var form = $(this).closest('ul').siblings('form');
		if (!$(this).hasClass('chosen')) {
			var min_price = $(this).data('min');
			var max_price = $(this).data('max');

			if (min_price !== '') {
				form.find('input[name="min_price"]').val(min_price);
			}
			else {
				form.find('input[name="min_price"]').remove();
			}
			if (max_price !== '') {
				form.find('input[name="max_price"]').val(max_price);
			}
			else {
				form.find('input[name="max_price"]').remove();
			}
		}
		else {
			form.find('input[name="min_price"]').remove();
			form.find('input[name="max_price"]').remove();
		}
		form.submit();
	});

	/* Product Filter By Brand */
	$('.product-filter-by-brand-wrapper ul input[type="checkbox"]').on('change', function () {
		var wrapper = $(this).parents('.product-filter-by-brand-wrapper');
		var query_type = wrapper.find('> .query-type').val();
		var checked = $(this).is(':checked');
		var val = new Array();
		if (query_type == 'or') {
			wrapper.find('ul input[type="checkbox"]').attr('checked', false);
			if (checked) {
				$(this).off('change');
				$(this).attr('checked', true);
				val.push($(this).val());
			}
		}
		else {
			wrapper.find('ul input[type="checkbox"]:checked').each(function (index, ele) {
				val.push($(ele).val());
			});
		}
		val = val.join(',');
		var form = wrapper.find('form');
		if (val != '') {
			form.find('input[name="product_brand"]').val(val);
		}
		else {
			form.find('input[name="product_brand"]').remove();
		}
		form.submit();
	});
});

function zeroise(str, max) {
	str = str.toString();
	return str.length < max ? zeroise('0' + str, max) : str;
}

class PLATR_Carousel {
	register($scope, $) {
		var carousel = this;

		/* [wrapper selector, slider selector, slider options (remove dynamic columns at last)] */
		var data = [
			['.platr-product-wrapper', '.products', { breakpoints: { 0: { slidesPerView: 1 }, 305: { slidesPerView: 2 }, 615: { slidesPerView: 3 }, 1000: { slidesPerView: 4 } } }]
			, ['.platr-product-in-category-tab-wrapper, .platr-product-in-product-type-tab-wrapper', '.products', { breakpoints: { 0: { slidesPerView: 1 }, 305: { slidesPerView: 2 }, 615: { slidesPerView: 3 }, 1000: { slidesPerView: 4 } } }]
			, ['.platr-product-deals-wrapper', '.products', { breakpoints: { 0: { slidesPerView: 1 }, 305: { slidesPerView: 2 }, 615: { slidesPerView: 3 }, 1000: { slidesPerView: 4 } } }]
			, ['.platr-product-category-wrapper', '.products', { breakpoints: { 0: { slidesPerView: 1 }, 280: { slidesPerView: 2 }, 600: { slidesPerView: 3 }, 1000: { slidesPerView: 4 }} }]
			, ['.platr-product-brand-wrapper', '.content-wrapper', { breakpoints: { 0: { slidesPerView: 1 }, 300: { slidesPerView: 2 }, 450: { slidesPerView: 3 }, 600: { slidesPerView: 4 }, 715: { slidesPerView: 5 }, 900: { slidesPerView: 6 } } }]
			, ['.platr-products-widget-wrapper', null, { spaceBetween: 10, breakpoints: { 0: { slidesPerView: 1 } } }]
			, ['.platr-blogs-wrapper', '.blogs', { breakpoints: { 0: { slidesPerView: 1 }, 760: { slidesPerView: 2 }, 1200: { slidesPerView: 3 } } }]
			, ['.platr-logo-slider-wrapper', '.items', { breakpoints: { 0: { slidesPerView: 1 }, 300: { slidesPerView: 2 }, 450: { slidesPerView: 3 }, 600: { slidesPerView: 4 }, 715: { slidesPerView: 5 }, 900: { slidesPerView: 6 } } }]
			, ['.platr-team-members', '.items', { breakpoints: { 0: { slidesPerView: 1 }, 500: { slidesPerView: 2 }, 620: { slidesPerView: 3 }, 1000: { slidesPerView: 4 } } }]
			, ['.platr-instagram-wrapper', null, { breakpoints: { 0: { slidesPerView: 1 }, 300: { slidesPerView: 2 }, 560: { slidesPerView: 3 }, 720: { slidesPerView: 4 }, 1000: { slidesPerView: 5 }, 1200: { slidesPerView: 6 } } }]
			, ['.platr-testimonial-wrapper', '.items', { breakpoints: { 0: { slidesPerView: 1 }, 600: { slidesPerView: 2 } } }]
			, ['.platr-blogs-widget-wrapper', null, { spaceBetween: 10, breakpoints: { 0: { slidesPerView: 1 } } }]
			, ['.platr-recent-comments-widget-wrapper', null, { spaceBetween: 10, breakpoints: { 0: { slidesPerView: 1 } } }]
			, ['.platr-blogs-wrapper .thumbnail.gallery', 'figure', { effect: 'fade', fadeEffect: { crossFade: true }, spaceBetween: 10, breakpoints: { 0: { slidesPerView: 1 } }, simulateTouch: false, allowTouchMove: false, autoplay: true }]
		];

		$.each(data, function (index, value) {
			carousel.run(value, $);
		});
	}

	run(data, $) {
		$(data[0]).each(function (index) {
			if (!$(this).hasClass('platr-slider') || $(this).hasClass('generated-slider')) {
				return;
			}

			var wrapper = $(this);
			if (typeof data[1] != 'undefined' && data[1] != null) {
				var swiper = wrapper.find(data[1]);
			} else {
				var swiper = wrapper;
			}

			if (swiper.find('> *').length <= 1) {
				wrapper.removeClass('loading');
				wrapper.find('.loading').removeClass('loading');

				return;
			}

			var unique_class = 'swiper-' + Math.floor(Math.random() * 10000) + '-' + index;
			var show_nav = typeof wrapper.attr('data-nav') != 'undefined' && wrapper.attr('data-nav') == 1 ? true : false;
			var show_dots = typeof wrapper.attr('data-dots') != 'undefined' && wrapper.attr('data-dots') == 1 ? true : false;
			var auto_play = typeof wrapper.attr('data-autoplay') != 'undefined' && wrapper.attr('data-autoplay') == 1 ? true : false;
			var columns = typeof wrapper.attr('data-columns') != 'undefined' ? parseInt(wrapper.attr('data-columns')) : 5;
			var disable_responsive = typeof wrapper.attr('data-disable_responsive') != 'undefined' && wrapper.attr('data-disable_responsive') == 1 ? true : false;

			wrapper.addClass('generated-slider');
			swiper.addClass('swiper ' + unique_class);
			swiper.find('> *').addClass('swiper-slide');
			swiper.wrapInner('<div class="swiper-wrapper"></div>');

			var slider_options = {
				loop: true
				, spaceBetween: 0
				, pauseOnMouseEnter: true
				, breakpointsBase: 'container'
				, on: {
					init: function () {
						wrapper.removeClass('loading');
						wrapper.find('.loading').removeClass('loading');
						$(window).trigger('platr_slider_middle_navigation_position', [swiper]);
					}
					,resize: function(){
						$(window).trigger('platr_slider_middle_navigation_position', [swiper]);
					}
				}
			};

			/* RTL */
			if ($('body').hasClass('rtl')) {
				swiper.attr('dir', 'rtl');
			}

			/* Navigation */
			if (show_nav) {
				swiper.append('<div class="swiper-button-prev"></div><div class="swiper-button-next"></div>');

				slider_options.navigation = {
					nextEl: '.swiper-button-next'
					, prevEl: '.swiper-button-prev'
				};
			}

			/* Pagination */
			if (show_dots) {
				swiper.append('<div class="swiper-pagination"></div>');

				slider_options.pagination = {
					el: '.swiper-pagination'
					, clickable: true
				};
			}

			/* Autoplay */
			if (auto_play) {
				slider_options.autoplay = {
					delay: 4000
					, disableOnInteraction: false
					, pauseOnMouseEnter: true
				};
			}

			if (typeof data[2] != 'undefined' && data[2] != null) {
				$.extend(slider_options, data[2]);

				if (typeof data[2].breakpoints != 'undefined') { /* change breakpoints => add dynamic columns at last */
					switch (data[0]) {
						case '.platr-product-wrapper':
							slider_options.breakpoints[1200] = { slidesPerView: columns };
							break;
						case '.platr-product-in-category-tab-wrapper, .platr-product-in-product-type-tab-wrapper':
							slider_options.breakpoints[1200] = { slidesPerView: columns };
							break;
						case '.platr-product-deals-wrapper':
							slider_options.breakpoints[1200] = { slidesPerView: columns };
							break;
						case '.platr-blogs-wrapper':
							slider_options.breakpoints[1000] = { slidesPerView: columns };
							break;
						case '.platr-product-category-wrapper':
							slider_options.breakpoints[1200] = { slidesPerView: columns };
							break;
						case '.platr-product-brand-wrapper':
							slider_options.breakpoints[900] = { slidesPerView: columns };
							break;
						case '.platr-team-members':
							slider_options.breakpoints[1000] = { slidesPerView: columns };
							break;
						case '.platr-testimonial-wrapper':
							slider_options.breakpoints[992] = { slidesPerView: columns };
							break;
						case '.platr-instagram-wrapper':
							slider_options.breakpoints[1200] = { slidesPerView: columns };
							break;
						default:
					}
				}
			}

			if (wrapper.hasClass('use-logo-setting')) { /* Product Brands - Logos */
				var break_point = wrapper.data('break_point');
				var item = wrapper.data('item');

				if (break_point.length > 0) {
					slider_options.breakpoints = {};
					for (var i = 0; i < break_point.length; i++) {
						slider_options.breakpoints[break_point[i]] = { slidesPerView: item[i] };
					}
				}
			}

			if (disable_responsive) {
				slider_options.breakpoints = { 0: { slidesPerView: columns } };
			}

			if (columns == 1) {
				slider_options.breakpoints = { 0: { slidesPerView: 1 } };
			}

			if (data[0] == '.platr-blogs-wrapper') {
				switch (columns) {
					case '1':
						slider_options.breakpoints = { 0: { slidesPerView: columns } };
						break;
					case '2':
						slider_options.breakpoints = { 0: { slidesPerView: 1 }, 700: { slidesPerView: columns } };
						break;
					default:
						slider_options.breakpoints = { 0: { slidesPerView: 1 }, 700: { slidesPerView: 2 }, 1000: { slidesPerView: columns } };
						break;
				}
			}

			new Swiper('.' + unique_class, slider_options);
		});
	}
}

function platr_register_carousel($scope, $) {
	var carousel = new PLATR_Carousel();
	carousel.register($scope, $);
}

function platr_register_masonry($scope, $) {
	if (typeof $.fn.isotope == 'function') {
		/* Blog */
		setTimeout(function () {
			$('.platr-blogs-wrapper.platr-masonry .blogs').isotope();
		}, 10);

		$('.platr-blogs-wrapper.platr-masonry').removeClass('loading');
	}
}

jQuery(window).on('elementor/frontend/init', function () {
	var elements = ['platr-products', 'platr-product-deals', 'platr-product-categories', 'platr-product-brands', 'platr-blogs'
		, 'platr-logos', 'platr-team-members', 'platr-testimonial'
		, 'platr-products-in-category-tabs', 'platr-products-in-product-type-tabs', 'platr-special-products'
		, 'wp-widget-platr_products', 'wp-widget-platr_blogs', 'wp-widget-platr_recent_comments', 'wp-widget-platr_instagram'];
	jQuery.each(elements, function (index, name) {
		elementorFrontend.hooks.addAction('frontend/element_ready/' + name + '.default', platr_register_carousel);
	});

	elementorFrontend.hooks.addAction('frontend/element_ready/platr-blogs.default', platr_register_masonry);
});