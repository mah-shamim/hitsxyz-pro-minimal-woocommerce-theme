<?php
/*** PLATR Team ***/
if( !class_exists('PLATR_Team_Members') ){
	class PLATR_Team_Members{
	
		public $post_type;
		public $thumb_size_name;
		public $thumb_size_array;
		
		function __construct(){
			$this->post_type = 'platr_team';
			$this->thumb_size_name = 'platr_team_thumb';
			$this->thumb_size_array = array(330, 390);
			$this->add_image_size();
			
			add_action('init', array($this, 'register_post_type'));
			
			if( is_admin() ){
				add_filter('enter_title_here', array($this, 'enter_title_here'));
				add_filter('manage_'.$this->post_type.'_posts_columns', array($this, 'custom_column_headers'), 10);
				add_action('manage_'.$this->post_type.'_posts_custom_column', array($this, 'custom_columns'), 10, 2);
			}
		}
		
		function add_image_size(){
			global $_wp_additional_image_sizes;
			if( !isset($_wp_additional_image_sizes[$this->thumb_size_name]) ){
				add_image_size($this->thumb_size_name, $this->thumb_size_array[0], $this->thumb_size_array[1], true);
			}
		}
		
		function register_post_type(){
			register_post_type($this->post_type, array(
				'labels' => array(
							'name' 					=> esc_html_x('Team Members', 'post type general name','plat'),
							'singular_name' 		=> esc_html_x('Team Members', 'post type singular name','plat'),
							'all_items' 			=> esc_html__('All Team Members', 'plat'),
							'add_new' 				=> esc_html_x('Add Member', 'Team','plat'),
							'add_new_item' 			=> esc_html__('Add Member','plat'),
							'edit_item' 			=> esc_html__('Edit Member','plat'),
							'new_item' 				=> esc_html__('New Member','plat'),
							'view_item' 			=> esc_html__('View Member','plat'),
							'search_items' 			=> esc_html__('Search Member','plat'),
							'not_found' 			=> esc_html__('No Member found','plat'),
							'not_found_in_trash' 	=> esc_html__('No Member found in Trash','plat'),
							'parent_item_colon' 	=> '',
							'menu_name' 			=> esc_html__('Team Members','plat'),
				)
				,'singular_label' 		=> esc_html__('Team','plat')
				,'public' 				=> false
				,'publicly_queryable' 	=> true
				,'exclude_from_search' 	=> true
				,'show_ui' 				=> true
				,'show_in_menu' 		=> true
				,'capability_type' 		=> 'page'
				,'hierarchical' 		=> false
				,'supports'  			=> array('title', 'custom-fields', 'editor', 'thumbnail')
				,'has_archive' 			=> false
				,'rewrite' 				=> array('slug' => str_replace('platr_', '', $this->post_type), 'with_front' => true)
				,'query_var' 			=> false
				,'can_export' 			=> true
				,'show_in_nav_menus' 	=> false
				,'menu_position' 		=> 5
				,'menu_icon' 			=> ''
			));	
		}
		
		function enter_title_here( $title ) {
			if( get_post_type() == $this->post_type ) {
				$title = esc_html__('Enter the member name here', 'plat');
			}
			return $title;
		}
		
		function get_team_members( $args = array() ){
			$defaults = array(
				'limit' => 5
				,'orderby' => 'menu_order'
				,'order' => 'DESC'
				,'id' => 0
				,'size' => $this->thumb_size_name
			);

			$args = wp_parse_args($args, $defaults);

			$query_args = array();
			$query_args['post_type'] = $this->post_type;
			$query_args['posts_per_page'] = $args['limit'];
			$query_args['orderby'] = $args['orderby'];
			$query_args['order'] = $args['order'];

			if ( is_numeric($args['id']) && (intval($args['id']) > 0) ) {
				$query_args['p'] = intval( $args['id'] );
			}

			/* Whitelist checks */
			if ( !in_array($query_args['orderby'], array( 'none', 'ID', 'author', 'title', 'date', 'modified', 'parent', 'rand', 'comment_count', 'menu_order', 'meta_value', 'meta_value_num' )) ) {
				$query_args['orderby'] = 'date';
			}

			if ( !in_array( $query_args['order'], array( 'ASC', 'DESC' ) ) ) {
				$query_args['order'] = 'DESC';
			}

			if ( !in_array( $query_args['post_type'], get_post_types() ) ) {
				$query_args['post_type'] = $this->post_type;
			}

			/* The Query */
			$query = get_posts( $query_args );

			/* The Display */
			if ( !is_wp_error( $query ) && is_array( $query ) && count( $query ) > 0 ) {
				foreach ( $query as $k => $v ) {
					$meta = get_post_custom( $v->ID );

					/* Get the image */
					$query[$k]->image = $this->get_image( $v->ID, $args['size'] );

					/* Get custom meta data */
				}
			} else {
				$query = false;
			}

			return $query;
		}
		
		function get_image( $id, $size = '' ){
			$response = '';

			if ( has_post_thumbnail( $id ) ) {
				if ( ( is_int( $size ) || ( 0 < intval( $size ) ) ) && ! is_array( $size ) ) {
					$size = array( intval( $size ), intval( $size ) );
				} elseif ( ! is_string( $size ) && ! is_array( $size ) ) {
					$size = $this->thumb_size_array;
				}
				$response = get_the_post_thumbnail( intval( $id ), $size );
			}

			return $response;
		}
		
		function custom_columns( $column_name, $id ){
			global $wpdb, $post;

			$meta = get_post_custom( $id );
			switch ( $column_name ) {
				case 'image':
					$value = '';
					$value = $this->get_image( $id, 40 );
					echo $value;
				break;
				case 'role':
					if( isset($meta['_role'][0]) ){
						echo $meta['_role'][0];
					}
					else{
						echo '';
					}
				break;
				default:
				break;

			}
		}
		
		function custom_column_headers( $defaults ){
			$new_columns = array( 'image' => esc_html__( 'Image', 'plat' ), 'role' => esc_html__( 'Role', 'plat' ) );
			$last_item = '';
			if( isset($defaults['title']) ) { $defaults['title'] = esc_html__('Member name', 'plat'); }
			if( isset($defaults['date']) ) { unset($defaults['date']); }
			if( count($defaults) > 2 ) {
				$last_item = array_slice($defaults, -1);
				array_pop($defaults);
			}
			
			$defaults = array_merge($defaults, $new_columns);
			if( $last_item != '' ) {
				foreach ( $last_item as $k => $v ) {
					$defaults[$k] = $v;
					break;
				}
			}

			return $defaults;
		}
		
	}
}
global $platr_team_members;
$platr_team_members = new PLATR_Team_Members();

/*** PLATR Testimonial ***/
if( !class_exists('PLATR_Testimonials') ){
	class PLATR_Testimonials{
		public $post_type;
		public $thumb_size_name;
		public $thumb_size_array;
		
		function __construct(){
			$this->post_type = 'platr_testimonial';
			$this->thumb_size_name = 'platr_testimonial_thumb';
			$this->thumb_size_array = array(180, 180);
			$this->add_image_size();
			
			add_action('init', array($this, 'register_post_type'));
			add_action('init', array($this, 'register_taxonomy'));
			
			if( is_admin() ){
				add_filter('enter_title_here', array($this, 'enter_title_here'));
				add_filter('manage_'.$this->post_type.'_posts_columns', array($this, 'custom_column_headers'), 10);
				add_action('manage_'.$this->post_type.'_posts_custom_column', array($this, 'custom_columns'), 10, 2);
			}
		}
		
		function add_image_size(){
			global $_wp_additional_image_sizes;
			if( !isset($_wp_additional_image_sizes[$this->thumb_size_name]) ){
				add_image_size($this->thumb_size_name, $this->thumb_size_array[0], $this->thumb_size_array[1], true);
			}
		}
		
		function register_post_type(){
			$labels = array(
				'name' 				=> esc_html_x( 'Testimonials', 'post type general name', 'plat' ),
				'singular_name' 	=> esc_html_x( 'Testimonial', 'post type singular name', 'plat' ),
				'add_new' 			=> esc_html_x( 'Add New', 'testimonial', 'plat' ),
				'add_new_item' 		=> esc_html__( 'Add New Testimonial', 'plat' ),
				'edit_item' 		=> esc_html__( 'Edit Testimonial', 'plat' ),
				'new_item' 			=> esc_html__( 'New Testimonial', 'plat' ),
				'all_items' 		=> esc_html__( 'All Testimonials', 'plat' ),
				'view_item' 		=> esc_html__( 'View Testimonial', 'plat' ),
				'search_items' 		=> esc_html__( 'Search Testimonials', 'plat' ),
				'not_found' 		=> esc_html__( 'No Testimonials Found', 'plat' ),
				'not_found_in_trash'=> esc_html__( 'No Testimonials Found In Trash', 'plat' ),
				'parent_item_colon' => '',
				'menu_name' 		=> esc_html__( 'Testimonials', 'plat' )
			);
			$args = array(
				'labels' 			=> $labels,
				'public' 			=> false,
				'publicly_queryable'=> true,
				'show_ui' 			=> true,
				'show_in_menu' 		=> true,
				'query_var' 		=> true,
				'rewrite' 			=> array( 'slug' => $this->post_type ),
				'capability_type' 	=> 'post',
				'has_archive' 		=> 'platr_testimonials',
				'hierarchical' 		=> false,
				'supports' 			=> array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
				'menu_position' 	=> 5,
				'menu_icon' 		=> ''
			);
			register_post_type( $this->post_type, $args );
		}
		
		function register_taxonomy(){
			$args = array(
					'labels' => array(
								'name'                => esc_html_x( 'Categories', 'taxonomy general name', 'plat' ),
								'singular_name'       => esc_html_x( 'Category', 'taxonomy singular name', 'plat' ),
								'search_items'        => esc_html__( 'Search Categories', 'plat' ),
								'all_items'           => esc_html__( 'All Categories', 'plat' ),
								'parent_item'         => esc_html__( 'Parent Category', 'plat' ),
								'parent_item_colon'   => esc_html__( 'Parent Category:', 'plat' ),
								'edit_item'           => esc_html__( 'Edit Category', 'plat' ),
								'update_item'         => esc_html__( 'Update Category', 'plat' ),
								'add_new_item'        => esc_html__( 'Add New Category', 'plat' ),
								'new_item_name'       => esc_html__( 'New Category Name', 'plat' ),
								'menu_name'           => esc_html__( 'Categories', 'plat' )
								)
					,'public' 				=> true
					,'hierarchical' 		=> true
					,'show_ui' 				=> true
					,'show_admin_column' 	=> true
					,'query_var' 			=> true
					,'show_in_nav_menus' 	=> false
					,'show_tagcloud' 		=> false
					);
			register_taxonomy('platr_testimonial_cat', $this->post_type, $args);
		}
		
		function enter_title_here( $title ) {
			if( get_post_type() == $this->post_type ) {
				$title = esc_html__('Enter the customer\'s name here', 'plat');
			}
			return $title;
		}
		
		function get_image( $id, $size = '' ){
			$response = '';
			if( $size == '' ){
				$size = $this->thumb_size_array[0];
			}
			if ( has_post_thumbnail( $id ) ) {
				if ( ( is_int( $size ) || ( 0 < intval( $size ) ) ) && ! is_array( $size ) ) {
					$size = array( intval( $size ), intval( $size ) );
				} elseif ( ! is_string( $size ) && ! is_array( $size ) ) {
					$size = $this->thumb_size_array;
				}
				$response = get_the_post_thumbnail( intval( $id ), $size );
			} else {
				$gravatar_email = get_post_meta( $id, 'platr_gravatar_email', true );
				if ( '' != $gravatar_email && is_email( $gravatar_email ) ) {
					$response = get_avatar( $gravatar_email, $size );
				}
			}

			return $response;
		}
		
		function custom_columns( $column_name, $id ){
			global $wpdb, $post;

			$meta = get_post_custom( $id );
			switch ( $column_name ) {
				case 'image':
					$value = '';
					$value = $this->get_image( $id, 40 );
					echo $value;
				break;
				default:
				break;

			}
		}
		
		function custom_column_headers( $defaults ){
			$new_columns = array( 'image' => esc_html__( 'Image', 'plat' ) );
			$last_item = '';
			
			if( isset($defaults['date']) ) { unset($defaults['date']); }
			if( count($defaults) > 2 ) {
				$last_item = array_slice($defaults, -1);
				array_pop($defaults);
			}
			
			$defaults = array_merge($defaults, $new_columns);
			if( $last_item != '' ) {
				foreach ( $last_item as $k => $v ) {
					$defaults[$k] = $v;
					break;
				}
			}

			return $defaults;
		}
	}
}
global $platr_testimonials;
$platr_testimonials = new PLATR_Testimonials();

/*** PLATR Logos ***/
if( !class_exists('PLATR_Logos') ){
	class PLATR_Logos{
		public $post_type;
		public $thumb_size_name;
		public $thumb_size_array;
		
		function __construct(){
			$this->post_type = 'platr_logo';
			$this->thumb_size_name = 'platr_logo_thumb';
			$size_options = get_option('platr_logo_setting', array());
			$logo_width = isset($size_options['size']['width'])?$size_options['size']['width']:208;
			$logo_height = isset($size_options['size']['height'])?$size_options['size']['height']:110;
			$crop = isset($size_options['size']['crop']) && !$size_options['size']['crop']?false:true;
			$this->thumb_size_array = array($logo_width, $logo_height, $crop);
			$this->add_image_size();
			
			add_action('init', array($this, 'register_post_type'));
			add_action('init', array($this, 'register_taxonomy'));
			
			if( is_admin() ){
				add_action('admin_menu', array( $this, 'register_setting_page' ));
			}
		}
		
		function add_image_size(){
			global $_wp_additional_image_sizes;
			if( !isset($_wp_additional_image_sizes[$this->thumb_size_name]) ){
				add_image_size($this->thumb_size_name, $this->thumb_size_array[0], $this->thumb_size_array[1], $this->thumb_size_array[2]);
			}
		}
		
		function register_post_type(){
			$labels = array(
				'name' 				=> esc_html_x( 'Logos', 'post type general name', 'plat' ),
				'singular_name' 	=> esc_html_x( 'Logo', 'post type singular name', 'plat' ),
				'add_new' 			=> esc_html_x( 'Add New', 'logo', 'plat' ),
				'add_new_item' 		=> esc_html__( 'Add New Logo', 'plat' ),
				'edit_item' 		=> esc_html__( 'Edit Logo', 'plat' ),
				'new_item' 			=> esc_html__( 'New Logo', 'plat' ),
				'all_items' 		=> esc_html__( 'All Logos', 'plat' ),
				'view_item' 		=> esc_html__( 'View Logo', 'plat' ),
				'search_items' 		=> esc_html__( 'Search Logos', 'plat' ),
				'not_found' 		=> esc_html__( 'No Logos Found', 'plat' ),
				'not_found_in_trash'=> esc_html__( 'No Logos Found In Trash', 'plat' ),
				'parent_item_colon' => '',
				'menu_name' 		=> esc_html__( 'Logos', 'plat' )
			);
			$args = array(
				'labels' 			=> $labels,
				'public' 			=> false,
				'publicly_queryable'=> true,
				'show_ui' 			=> true,
				'show_in_menu' 		=> true,
				'query_var' 		=> true,
				'rewrite' 			=> array( 'slug' => str_replace('platr_', '', $this->post_type) ),
				'capability_type' 	=> 'post',
				'has_archive' 		=> false,
				'hierarchical' 		=> false,
				'supports' 			=> array( 'title', 'thumbnail' ),
				'menu_position' 	=> 5,
				'menu_icon' 		=> ''
			);
			register_post_type( $this->post_type, $args );
		}
		
		function register_taxonomy(){
			$args = array(
					'labels' => array(
								'name'                => esc_html_x( 'Categories', 'taxonomy general name', 'plat' ),
								'singular_name'       => esc_html_x( 'Category', 'taxonomy singular name', 'plat' ),
								'search_items'        => esc_html__( 'Search Categories', 'plat' ),
								'all_items'           => esc_html__( 'All Categories', 'plat' ),
								'parent_item'         => esc_html__( 'Parent Category', 'plat' ),
								'parent_item_colon'   => esc_html__( 'Parent Category:', 'plat' ),
								'edit_item'           => esc_html__( 'Edit Category', 'plat' ),
								'update_item'         => esc_html__( 'Update Category', 'plat' ),
								'add_new_item'        => esc_html__( 'Add New Category', 'plat' ),
								'new_item_name'       => esc_html__( 'New Category Name', 'plat' ),
								'menu_name'           => esc_html__( 'Categories', 'plat' )
								)
					,'public' 				=> true
					,'hierarchical' 		=> true
					,'show_ui' 				=> true
					,'show_admin_column' 	=> true
					,'query_var' 			=> true
					,'show_in_nav_menus' 	=> false
					,'show_tagcloud' 		=> false
					);
			register_taxonomy('platr_logo_cat', $this->post_type, $args);
		}
		
		function register_setting_page(){
			add_submenu_page('edit.php?post_type='.$this->post_type, esc_html__('Logo Settings','plat'), 
						esc_html__('Settings','plat'), 'manage_options', 'platr-logo-settings', array($this, 'setting_page_content'));
		}
		
		function setting_page_content(){
			$options_default = array(
							'size' => array(
								'width' => 208
								,'height' => 110
								,'crop' => 1
							)
							,'responsive' => array(
								'break_point'	=> array(0, 300, 450, 600, 715, 900)
								,'item'			=> array(1, 2, 3, 4, 5, 6)
							)
						);
						
			$options = get_option('platr_logo_setting', $options_default);
			if(isset($_POST['platr_logo_save_setting'])){
				$options['size']['width'] = $_POST['width'];
				$options['size']['height'] = $_POST['height'];
				$options['size']['crop'] = $_POST['crop'];
				$options['responsive']['break_point'] = $_POST['responsive']['break_point'];
				$options['responsive']['item'] = $_POST['responsive']['item'];
				update_option('platr_logo_setting', $options);
			}
			if( isset($_POST['platr_logo_reset_setting']) ){
				update_option('platr_logo_setting', $options_default);
				$options = $options_default;
			}
			?>
			<h2 class="platr-logo-settings-page-title"><?php esc_html_e('Logo Settings','plat'); ?></h2>
			<div id="platr-logo-setting-page-wrapper">
				<form method="post">
					<h3><?php esc_html_e('Image Size', 'plat'); ?></h3>
					<p class="description"><?php esc_html_e('You must regenerate thumbnails after changing','plat'); ?></p>
					<table class="form-table">
						<tbody>
							<tr>
								<th scope="row"><label><?php esc_html_e('Image width','plat'); ?></label></th>
								<td>
									<input type="number" min="1" step="1" name="width" value="<?php echo esc_attr($options['size']['width']); ?>" />
									<p class="description"><?php esc_html_e('Input image width (In pixels)','plat'); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label><?php esc_html_e('Image height','plat'); ?></label></th>
								<td>
									<input type="number" min="1" step="1" name="height" value="<?php echo esc_attr($options['size']['height']); ?>" />
									<p class="description"><?php esc_html_e('Input image height (In pixels)','plat'); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label><?php esc_html_e('Crop','plat'); ?></label></th>
								<td>
									<select name="crop">
										<option value="1" <?php echo ($options['size']['crop']==1)?'selected':''; ?>>Yes</option>
										<option value="0" <?php echo ($options['size']['crop']==0)?'selected':''; ?>>No</option>
									</select>
									<p class="description"><?php esc_html_e('Crop image after uploading','plat'); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
					<h3><?php esc_html_e('Slider Responsive Options', 'plat'); ?></h3>
					<div class="responsive-options-wrapper">
						<ul>
							<?php foreach( $options['responsive']['break_point'] as $k => $break){ ?>
							<li>
								<label><?php esc_html_e('Breakpoint from','plat'); ?></label>
								<input name="responsive[break_point][]" type="number" min="0" step="1" value="<?php echo (int)$break; ?>" class="small-text" />
								<span>px</span>
								<input name="responsive[item][]" type="number" min="0" step="1" value="<?php echo (int)$options['responsive']['item'][$k]; ?>" class="small-text" />
								<label><?php esc_html_e('Items','plat'); ?></label>
							</li>
							<?php } ?>
						</ul>
					</div>
					
					<input type="submit" name="platr_logo_save_setting" value="<?php esc_html_e('Save changes','plat'); ?>" class="button button-primary" />
					<input type="submit" name="platr_logo_reset_setting" value="<?php esc_html_e('Reset','plat'); ?>" class="button" />
				</form>
			</div>
			<script type="text/javascript">
				jQuery(function($){
					"use strict";
					$('input[name="platr_logo_reset_setting"]').on('click', function(e){
						var ok = confirm('Do you want to reset all settings?');
						if( !ok ){
							e.preventDefault();
						}
					});
				});
			</script>
			<?php
		}
	}
}
new PLATR_Logos();

/*** PLATR Footer Blocks ***/
if( !class_exists('PLATR_Footer_Blocks') ){
	class PLATR_Footer_Blocks{
		public $post_type;
		
		function __construct(){
			$this->post_type = 'platr_footer_block';
			add_action('init', array($this, 'register_post_type'));
		}
		
		function register_post_type(){
			$labels = array(
				'name' 				=> esc_html_x( 'Footer Blocks', 'post type general name', 'plat' ),
				'singular_name' 	=> esc_html_x( 'Footer Block', 'post type singular name', 'plat' ),
				'add_new' 			=> esc_html_x( 'Add New', 'logo', 'plat' ),
				'add_new_item' 		=> esc_html__( 'Add New', 'plat' ),
				'edit_item' 		=> esc_html__( 'Edit Footer Block', 'plat' ),
				'new_item' 			=> esc_html__( 'New Footer Block', 'plat' ),
				'all_items' 		=> esc_html__( 'All Footer Blocks', 'plat' ),
				'view_item' 		=> esc_html__( 'View Footer Block', 'plat' ),
				'search_items' 		=> esc_html__( 'Search Footer Block', 'plat' ),
				'not_found' 		=> esc_html__( 'No Footer Blocks Found', 'plat' ),
				'not_found_in_trash'=> esc_html__( 'No Footer Blocks Found In Trash', 'plat' ),
				'parent_item_colon' => '',
				'menu_name' 		=> esc_html__( 'Footer Blocks', 'plat' )
			);
			$args = array(
				'labels' 			=> $labels,
				'public' 			=> true,
				'publicly_queryable'=> true,
				'show_ui' 			=> true,
				'show_in_menu' 		=> true,
				'query_var' 		=> true,
				'rewrite' 			=> array( 'slug' => $this->post_type ),
				'capability_type' 	=> 'post',
				'has_archive' 		=> false,
				'hierarchical' 		=> false,
				'supports' 			=> array( 'title', 'editor' ),
				'menu_position' 	=> 5,
			);
			register_post_type( $this->post_type, $args );
		}
	}
}
new PLATR_Footer_Blocks();

/*** PLATR Mega Menu ***/
if( !class_exists('PLATR_Mega_Menus') ){
	class PLATR_Mega_Menus{
		public $post_type = 'platr_mega_menu';
		
		function __construct(){
			add_action( 'init', array($this, 'register_post_type') );
		}
		
		function register_post_type(){
			$labels = array(
				'name' 				=> esc_html_x( 'Mega Menus', 'post type general name', 'plat' ),
				'singular_name' 	=> esc_html_x( 'Mega Menu', 'post type singular name', 'plat' ),
				'add_new' 			=> esc_html_x( 'Add New', 'mega_menu', 'plat' ),
				'add_new_item' 		=> esc_html__( 'Add New', 'plat' ),
				'edit_item' 		=> esc_html__( 'Edit Mega Menu', 'plat' ),
				'new_item' 			=> esc_html__( 'New Mega Menu', 'plat' ),
				'all_items' 		=> esc_html__( 'All Mega Menus', 'plat' ),
				'view_item' 		=> esc_html__( 'View Mega Menu', 'plat' ),
				'search_items' 		=> esc_html__( 'Search Mega Menu', 'plat' ),
				'not_found' 		=> esc_html__( 'No Mega Menus Found', 'plat' ),
				'not_found_in_trash'=> esc_html__( 'No Mega Menus Found In Trash', 'plat' ),
				'parent_item_colon' => '',
				'menu_name' 		=> esc_html__( 'Mega Menus', 'plat' )
			);
			$args = array(
				'labels' 			=> $labels,
				'public' 			=> true,
				'publicly_queryable'=> true,
				'show_ui' 			=> true,
				'show_in_menu' 		=> true,
				'query_var' 		=> true,
				'rewrite' 			=> array( 'slug' => $this->post_type ),
				'capability_type' 	=> 'post',
				'has_archive' 		=> false,
				'hierarchical' 		=> false,
				'supports' 			=> array( 'title', 'editor' ),
				'menu_position' 	=> 5,
			);
			register_post_type( $this->post_type, $args );
		}
	}
}
new PLATR_Mega_Menus();

/*** Product Brands ***/
if( !class_exists('PLATR_Product_Brands') ){
	class PLATR_Product_Brands{
		function __construct(){
			add_action('init', array($this, 'register_taxonomy'));
			add_action('platr_product_brand_add_form_fields', array($this, 'add_brand_fields'));
			add_action('platr_product_brand_edit_form_fields', array($this, 'edit_brand_fields'), 10);
			add_action('created_term', array($this, 'save_brand_fields'), 10, 3);
			add_action('edit_term', array($this, 'save_brand_fields'), 10, 3);
			add_action('delete_term', array($this, 'delete_term'), 5);
			
			add_filter('manage_edit-platr_product_brand_columns', array($this, 'product_brand_columns'));
			add_filter('manage_platr_product_brand_custom_column', array($this, 'product_brand_column'), 10, 3);
			// Maintain hierarchy of terms
			add_filter('wp_terms_checklist_args', array($this, 'disable_checked_ontop'));

			/* Register field permalink */
			add_action('load-options-permalink.php', array($this, 'register_custom_fields'));
		}
		
		function register_taxonomy(){
			if( taxonomy_exists( 'platr_product_brand' ) ){
				return;
			}

			$taxanomy_slug = get_option('platr_product_brand_permalink');

			$args = array(
					'hierarchical'           => true
					,'label'                 => esc_html__( 'Brands', 'plat' )
					,'labels' => array(
							'name'               => esc_html__( 'Product brands', 'plat' )
							,'singular_name'     => esc_html__( 'Brand', 'plat' )
							,'menu_name'         => esc_html__( 'Brands', 'plat' )
							,'search_items'      => esc_html__( 'Search brands', 'plat' )
							,'all_items'         => esc_html__( 'All brands', 'plat' )
							,'parent_item'       => esc_html__( 'Parent brand', 'plat' )
							,'parent_item_colon' => esc_html__( 'Parent brand:', 'plat' )
							,'edit_item'         => esc_html__( 'Edit brand', 'plat' )
							,'update_item'       => esc_html__( 'Update brand', 'plat' )
							,'add_new_item'      => esc_html__( 'Add new brand', 'plat' )
							,'new_item_name'     => esc_html__( 'New brand name', 'plat' )
							,'not_found'         => esc_html__( 'No brands found', 'plat' )
						)
					,'show_ui'               => true
					,'query_var'             => true
					,'capabilities'          => array(
						'manage_terms'  => 'manage_product_terms'
						,'edit_terms'   => 'edit_product_terms'
						,'delete_terms' => 'delete_product_terms'
						,'assign_terms' => 'assign_product_terms'
					)
					,'rewrite'          => array(
						'slug'          => 'product-brand'
						,'with_front'   => false
						,'hierarchical' => true
					)
				);
		
			if( $taxanomy_slug ){
				$args['rewrite']['slug'] = sanitize_title_with_dashes( $taxanomy_slug );
			}

			register_taxonomy( 'platr_product_brand', array( 'product' ), $args );
		}
		
		function add_brand_fields(){
			?>
			<div class="form-field term-thumbnail-wrap">
				<label><?php esc_html_e( 'Thumbnail', 'plat' ); ?></label>
				<div id="product_brand_thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( wc_placeholder_img_src() ); ?>" width="60px" height="60px" /></div>
				<div style="line-height: 60px;">
					<input type="hidden" id="product_brand_thumbnail_id" name="product_brand_thumbnail_id" />
					<button type="button" class="upload_image_button button"><?php esc_html_e( 'Upload/Add image', 'plat' ); ?></button>
					<button type="button" class="remove_image_button button"><?php esc_html_e( 'Remove image', 'plat' ); ?></button>
				</div>
				<script type="text/javascript">

					// Only show the "remove image" button when needed
					if ( ! jQuery( '#product_brand_thumbnail_id' ).val() ) {
						jQuery( '.remove_image_button' ).hide();
					}

					// Uploading files
					var file_frame;

					jQuery( document ).on( 'click', '.upload_image_button', function( event ) {

						event.preventDefault();

						// If the media frame already exists, reopen it.
						if ( file_frame ) {
							file_frame.open();
							return;
						}

						// Create the media frame.
						file_frame = wp.media.frames.downloadable_file = wp.media({
							title: '<?php esc_html_e( 'Choose an image', 'plat' ); ?>',
							button: {
								text: '<?php esc_html_e( 'Use image', 'plat' ); ?>'
							},
							multiple: false
						});

						// When an image is selected, run a callback.
						file_frame.on( 'select', function() {
							var attachment           = file_frame.state().get( 'selection' ).first().toJSON();
							var attachment_thumbnail = attachment.sizes.thumbnail || attachment.sizes.full;

							jQuery( '#product_brand_thumbnail_id' ).val( attachment.id );
							jQuery( '#product_brand_thumbnail' ).find( 'img' ).attr( 'src', attachment_thumbnail.url );
							jQuery( '.remove_image_button' ).show();
						});

						// Finally, open the modal.
						file_frame.open();
					});

					jQuery( document ).on( 'click', '.remove_image_button', function() {
						jQuery( '#product_brand_thumbnail' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
						jQuery( '#product_brand_thumbnail_id' ).val( '' );
						jQuery( '.remove_image_button' ).hide();
						return false;
					});

					jQuery( document ).ajaxComplete( function( event, request, options ) {
						if ( request && 4 === request.readyState && 200 === request.status
							&& options.data && 0 <= options.data.indexOf( 'action=add-tag' ) ) {

							var res = wpAjax.parseAjaxResponse( request.responseXML, 'ajax-response' );
							if ( ! res || res.errors ) {
								return;
							}
							// Clear Thumbnail fields on submit
							jQuery( '#product_brand_thumbnail' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
							jQuery( '#product_brand_thumbnail_id' ).val( '' );
							jQuery( '.remove_image_button' ).hide();
							return;
						}
					} );
				</script>
				<div class="clear"></div>
			</div>

			<?php
		}
		
		function edit_brand_fields( $term ){
			$thumbnail_id = absint(get_term_meta($term->term_id, 'thumbnail_id', true));

			if( $thumbnail_id ){
				$image = wp_get_attachment_thumb_url( $thumbnail_id );
			}else{
				$image = wc_placeholder_img_src();
			}
			?>
			<tr class="form-field">
				<th scope="row" valign="top"><label><?php esc_html_e( 'Thumbnail', 'plat' ); ?></label></th>
				<td>
					<div id="product_brand_thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( $image ); ?>" width="60px" height="60px" /></div>
					<div style="line-height: 60px;">
						<input type="hidden" id="product_brand_thumbnail_id" name="product_brand_thumbnail_id" value="<?php echo $thumbnail_id; ?>" />
						<button type="button" class="upload_image_button button"><?php esc_html_e( 'Upload/Add image', 'plat' ); ?></button>
						<button type="button" class="remove_image_button button"><?php esc_html_e( 'Remove image', 'plat' ); ?></button>
					</div>
					<script type="text/javascript">

						// Only show the "remove image" button when needed
						if ( '0' === jQuery( '#product_brand_thumbnail_id' ).val() ) {
							jQuery( '.remove_image_button' ).hide();
						}

						// Uploading files
						var file_frame;

						jQuery( document ).on( 'click', '.upload_image_button', function( event ) {

							event.preventDefault();

							// If the media frame already exists, reopen it.
							if ( file_frame ) {
								file_frame.open();
								return;
							}

							// Create the media frame.
							file_frame = wp.media.frames.downloadable_file = wp.media({
								title: '<?php esc_html_e( 'Choose an image', 'plat' ); ?>',
								button: {
									text: '<?php esc_html_e( 'Use image', 'plat' ); ?>'
								},
								multiple: false
							});

							// When an image is selected, run a callback.
							file_frame.on( 'select', function() {
								var attachment           = file_frame.state().get( 'selection' ).first().toJSON();
								var attachment_thumbnail = attachment.sizes.thumbnail || attachment.sizes.full;

								jQuery( '#product_brand_thumbnail_id' ).val( attachment.id );
								jQuery( '#product_brand_thumbnail' ).find( 'img' ).attr( 'src', attachment_thumbnail.url );
								jQuery( '.remove_image_button' ).show();
							});

							// Finally, open the modal.
							file_frame.open();
						});

						jQuery( document ).on( 'click', '.remove_image_button', function() {
							jQuery( '#product_brand_thumbnail' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
							jQuery( '#product_brand_thumbnail_id' ).val( '' );
							jQuery( '.remove_image_button' ).hide();
							return false;
						});

					</script>
					<div class="clear"></div>
				</td>
			</tr>

			<?php
		}
		
		function save_brand_fields( $term_id, $tt_id = '', $taxonomy = '' ){
			if( isset( $_POST['product_brand_thumbnail_id'] ) && 'platr_product_brand' === $taxonomy ){
				update_term_meta( $term_id, 'thumbnail_id', absint( $_POST['product_brand_thumbnail_id'] ) );
			}
		}
		
		function delete_term( $term_id ){
			delete_term_meta( $term_id, 'thumbnail_id' );
		}
		
		function product_brand_columns( $columns ){
			$new_columns = array();

			if ( isset( $columns['cb'] ) ) {
				$new_columns['cb'] = $columns['cb'];
				unset( $columns['cb'] );
			}

			$new_columns['thumb'] = esc_html__( 'Image', 'plat' );

			$columns = array_merge( $new_columns, $columns );

			return $columns;
		}
		
		function product_brand_column( $columns, $column, $id ){
			if( 'thumb' === $column ){

				$thumbnail_id = get_term_meta( $id, 'thumbnail_id', true );

				if( $thumbnail_id ){
					$image = wp_get_attachment_thumb_url( $thumbnail_id );
				}else{
					$image = wc_placeholder_img_src();
				}

				$image    = str_replace( ' ', '%20', $image );
				$columns .= '<img src="' . esc_url( $image ) . '" alt="' . esc_attr__( 'Thumbnail', 'plat' ) . '" class="wp-post-image" height="48" width="48" />';
			}
			return $columns;
		}
		
		function disable_checked_ontop( $args ){
			if( !empty( $args['taxonomy'] ) && 'platr_product_brand' === $args['taxonomy'] ){
				$args['checked_ontop'] = false;
			}
			return $args;
		}

		function register_custom_fields (){
			if( isset($_POST['platr_product_brand_permalink']) ){
				update_option('platr_product_brand_permalink', sanitize_title_with_dashes( $_POST['platr_product_brand_permalink'] ) );
			}

			add_settings_field('platr_product_brand_permalink', esc_html__( 'Product brand base', 'plat') , array($this, 'permalink_field_callback'), 'permalink', 'optional');
		}

		function permalink_field_callback() {
			$option = get_option('platr_product_brand_permalink');

			echo '<input type="text" value="' . esc_attr( $option ) . '" name="platr_product_brand_permalink" id="platr_product_brand_permalink" class="regular-text" />';
		}
	}
}
new PLATR_Product_Brands();

/*** PLATR Size Chart ***/
if( !class_exists('PLATR_Size_Chart') ){
	class PLATR_Size_Chart{
	
		public $post_type = 'platr_size_chart';

		function __construct(){
			add_action('init', array($this, 'register_post_type'));
		}
		
		function register_post_type(){
			$labels = array(
				'name' 				=> esc_html_x( 'Size Charts', 'post type general name', 'plat' ),
				'singular_name' 	=> esc_html_x( 'Size Chart', 'post type singular name', 'plat' ),
				'add_new' 			=> esc_html_x( 'Add Size Chart', 'size chart', 'plat' ),
				'add_new_item' 		=> esc_html__( 'Add Size Chart', 'plat' ),
				'edit_item' 		=> esc_html__( 'Edit Size Chart', 'plat' ),
				'new_item' 			=> esc_html__( 'New Size Chart', 'plat' ),
				'all_items' 		=> esc_html__( 'All Size Charts', 'plat' ),
				'view_item' 		=> esc_html__( 'View Size Chart', 'plat' ),
				'search_items' 		=> esc_html__( 'Search Size Charts', 'plat' ),
				'not_found' 		=> esc_html__( 'No Size Chart Found', 'plat' ),
				'not_found_in_trash'=> esc_html__( 'No Size Chart Found In Trash', 'plat' ),
				'parent_item_colon' => '',
				'menu_name' 		=> esc_html__( 'Size Charts', 'plat' )
			);
			$args = array(
				'labels' 			=> $labels,
				'public' 			=> false,
				'publicly_queryable'=> true,
				'show_ui' 			=> true,
				'show_in_menu' 		=> true,
				'query_var' 		=> true,
				'rewrite' 			=> array( 'slug' => str_replace('platr_', '', $this->post_type) ),
				'capability_type' 	=> 'post',
				'has_archive' 		=> false,
				'hierarchical' 		=> false,
				'supports' 			=> array( 'title', 'editor' ),
				'menu_position' 	=> 5,
				'menu_icon' 		=> ''
			);
			register_post_type( $this->post_type, $args );
		}
	}
}
new PLATR_Size_Chart();
?>