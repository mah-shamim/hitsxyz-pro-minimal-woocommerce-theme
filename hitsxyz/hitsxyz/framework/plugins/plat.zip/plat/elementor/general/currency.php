<?php
use Elementor\Controls_Manager;

class PLATR_Elementor_Widget_Currency_Switcher extends PLATR_Elementor_Widget_Base{
	public function get_name(){
        return 'platr-currency-switcher';
    }
	
	public function get_title(){
        return esc_html__( 'PLATR Currency Switcher', 'plat' );
    }
	
	public function get_categories(){
        return array( 'platr-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-product-price';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'plat' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'heading'
            ,array(
                'label' 		=> esc_html__( 'Note: This element is used for the WooCommerce Multilingual plugin', 'plat' )
                ,'type' 		=> Controls_Manager::HEADING	
                ,'separator' 	=> 'after'
            )
        );
		
		$this->add_control(
            'dropdown_position'
            ,array(
                'label' 		=> esc_html__( 'Dropdown position', 'plat' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'default'
				,'options'		=> array(
									'default'	=> esc_html__( 'Default', 'plat' )
									,'up'		=> esc_html__( 'Up', 'plat' )
								)			
                ,'description' 	=> ''
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		if( !function_exists('platrxyz_woocommerce_multilingual_currency_switcher') ){
			return;
		}
		
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'dropdown_position'	=> 'default'
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		?>
		<div class="platr-currency-switcher dropdown-<?php echo esc_attr($dropdown_position); ?>">
			<?php platrxyz_woocommerce_multilingual_currency_switcher(); ?>
		</div>
		<?php
	}
}

$widgets_manager->register( new PLATR_Elementor_Widget_Currency_Switcher() );