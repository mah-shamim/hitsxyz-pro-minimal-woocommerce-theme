<?php 
$options = array();

$options[] = array(
				'id'		=> 'url'
				,'label'	=> esc_html__('URL', 'plat')
				,'desc'		=> esc_html__('Enter an URL that applies to this feature. For example: https://pasarkoin.co.id/pltrx-features/', 'plat')
				,'type'		=> 'text'
			);
?>