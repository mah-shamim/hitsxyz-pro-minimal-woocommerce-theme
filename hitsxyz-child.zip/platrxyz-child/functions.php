<?php 
function platrxyz_child_register_scripts(){
    $parent_style = 'platrxyz-style';

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array('font-awesome-5', 'platrxyz-reset'), platrxyz_get_theme_version() );
    wp_enqueue_style( 'platrxyz-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style )
    );
}
add_action( 'wp_enqueue_scripts', 'platrxyz_child_register_scripts', 99 );